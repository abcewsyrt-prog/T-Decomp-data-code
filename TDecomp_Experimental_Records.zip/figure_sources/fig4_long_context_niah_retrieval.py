from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# =========================================================================
# Figure 4 | Long-Context Scaling & 100-Trial Full-String 16K NIAH Retrieval
# Dimensions: 7.20 in x 4.20 in (Double Column Width)
# Font Hierarchy: Panel Titles 7.5pt bold, Axis Labels 6.8pt bold, Ticks 6.0pt, Heatmap cells 5.8pt
# =========================================================================

fig = plt.figure(figsize=(7.20, 4.20), dpi=300)

plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial']
plt.rcParams['mathtext.fontset'] = 'dejavusans'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
plt.rcParams['axes.edgecolor'] = '#64748B'
plt.rcParams['axes.linewidth'] = 0.8

csv_path = str(Path(__file__).resolve().parent / '完整1K至16K检索结果.csv')
df_ret = pd.read_csv(csv_path)

gs = fig.add_gridspec(2, 2, height_ratios=[1.0, 1.15], width_ratios=[1.0, 1.0],
                      wspace=0.32, hspace=0.45,
                      left=0.08, right=0.92, top=0.92, bottom=0.10)

# -------------------------------------------------------------
# Panel (a): Context Horizon Error Accumulation (Mamba-790M Historical)
# -------------------------------------------------------------
ax1 = fig.add_subplot(gs[0, 0])
ax1.set_facecolor('#FFFFFF')
ax1.spines['top'].set_visible(False)
ax1.spines['right'].set_visible(False)

horizons = ['1K', '2K', '4K', '8K', '16K']
h_x = np.arange(len(horizons))

ppl_ref = [10.92, 11.05, 11.89, 12.86, 42.16]
ppl_u8 = [11.45, 11.82, 13.67, 18.47, 58.32]
ppl_td_bal = [11.24, 11.38, 12.89, 24.15, 89.47]
ppl_td_agg = [22.30, 25.70, 81.80, 1391.64, 3.6e9]
ppl_u4 = [1.8e13, 1.8e14, 5.2e14, 3.1e15, 1.3e16]

ax1.plot(h_x, ppl_u4, 'x:', markersize=3.5, lw=1.1, color='#991B1B', label='Uniform INT4')
ax1.plot(h_x, ppl_td_agg, '^--', markersize=3.5, lw=1.1, color='#D97706', label='TD Aggressive (5.7b)')
ax1.plot(h_x, ppl_td_bal, 'o-', markersize=4.0, lw=1.4, color='#2563EB', label='TD Balanced (6.8b)')
ax1.plot(h_x, ppl_u8, 's--', markersize=3.5, lw=1.1, color='#059669', label='Uniform INT8')
ax1.plot(h_x, ppl_ref, 'D:', markersize=3.0, lw=1.1, color='#0F172A', label='Reference FP32')

ax1.set_yscale('log')
ax1.set_xticks(h_x)
ax1.set_xticklabels(horizons, fontsize=6.2)
ax1.set_ylim(5.0, 5e16)
ax1.set_xlabel("Context Horizon Length", fontsize=6.8, fontweight='bold', color='#1E293B', labelpad=3)
ax1.set_ylabel("Perplexity (Log Scale)", fontsize=6.8, fontweight='bold', color='#1E293B', labelpad=4)
ax1.set_title("a   Mamba-790M: Context PPL (Historical)", fontsize=7.5, fontweight='bold', color='#0F172A', loc='left', pad=6)
ax1.tick_params(axis='both', labelsize=6.0, direction='out', length=2.5, pad=2)

ax1.legend(fontsize=4.8, loc='center left', bbox_to_anchor=(0.02, 0.58), frameon=False, borderpad=0.1, handlelength=1.0)

# -------------------------------------------------------------
# Panel (b): Full-String Recall vs Length (RWKV-7 2.9B New 100-Trial)
# -------------------------------------------------------------
ax2 = fig.add_subplot(gs[0, 1])
ax2.set_facecolor('#FFFFFF')
ax2.spines['top'].set_visible(False)
ax2.spines['right'].set_visible(False)

lengths = [1024, 2048, 4096, 8192, 16384]
x_pts = np.arange(len(lengths))

acc_ref = [100.0 * df_ret[(df_ret['length']==l) & (df_ret['configuration']=='reference')]['successes'].sum() / 500.0 for l in lengths]
acc_u8  = [100.0 * df_ret[(df_ret['length']==l) & (df_ret['configuration']=='uniform8')]['successes'].sum() / 500.0 for l in lengths]
acc_td  = [100.0 * df_ret[(df_ret['length']==l) & (df_ret['configuration']=='masked_ema_8_6')]['successes'].sum() / 500.0 for l in lengths]
acc_u4  = [100.0 * df_ret[(df_ret['length']==l) & (df_ret['configuration']=='uniform4')]['successes'].sum() / 500.0 for l in lengths]

# Concentric markers & distinct line patterns to resolve identical 100% trajectories without altering data
ax2.plot(x_pts, acc_ref, color='#0F172A', lw=2.2, alpha=0.35, label='Reference (100.0%)', zorder=2)
ax2.plot(x_pts, acc_ref, 'D', markersize=5.5, color='#0F172A', fillstyle='none', mew=1.0, zorder=2)

ax2.plot(x_pts, acc_u8, 's--', markersize=4.2, lw=1.3, color='#059669', label='Uniform INT8 (100.0%)', zorder=3)
ax2.plot(x_pts, acc_td, 'o-', markersize=2.6, lw=1.0, color='#2563EB', label='T-Decomp (100.0%)', zorder=4)
ax2.plot(x_pts, acc_u4, 'x-.', markersize=4.0, lw=1.3, color='#DC2626', label='Uniform INT4 (0.0% @ 16K)', zorder=3)

ax2.set_xticks(x_pts)
ax2.set_xticklabels(horizons, fontsize=6.2)
ax2.set_ylim(-5, 115)
ax2.set_xlabel("Context Length (Tokens)", fontsize=6.8, fontweight='bold', color='#1E293B', labelpad=3)
ax2.set_ylabel("Exact Recall (%)", fontsize=6.8, fontweight='bold', color='#1E293B', labelpad=4)
ax2.set_title("b   RWKV-7 2.9B: 16K Needle Retrieval (New)", fontsize=7.5, fontweight='bold', color='#0F172A', loc='left', pad=6)
ax2.tick_params(axis='both', labelsize=6.0, direction='out', length=2.5, pad=2)

ax2.legend(fontsize=4.8, loc='lower left', frameon=False, borderpad=0.1, handlelength=1.1)

# -------------------------------------------------------------
# Panel (c): 25-Cell Heatmaps (T-Decomp vs Uniform INT4)
# -------------------------------------------------------------
sub_gs = gs[1, :].subgridspec(1, 2, wspace=0.28)
ax3_td = fig.add_subplot(sub_gs[0, 0])
ax3_u4 = fig.add_subplot(sub_gs[0, 1])

depths = [0.1, 0.3, 0.5, 0.7, 0.9]
depth_labels = ['10%', '30%', '50%', '70%', '90%']

mat_td = np.zeros((len(depths), len(lengths)))
mat_u4 = np.zeros((len(depths), len(lengths)))

for i, d in enumerate(depths):
    for j, l in enumerate(lengths):
        mat_td[i, j] = df_ret[(df_ret['length']==l) & (df_ret['depth']==d) & (df_ret['configuration']=='masked_ema_8_6')]['successes'].values[0]
        mat_u4[i, j] = df_ret[(df_ret['length']==l) & (df_ret['depth']==d) & (df_ret['configuration']=='uniform4')]['successes'].values[0]

# Render T-Decomp heatmap with crisp white text
im1 = ax3_td.imshow(mat_td, cmap='Greens', vmin=0, vmax=100, aspect='auto')
ax3_td.set_xticks(range(len(lengths)))
ax3_td.set_xticklabels(horizons, fontsize=6.0)
ax3_td.set_yticks(range(len(depths)))
ax3_td.set_yticklabels(depth_labels, fontsize=6.0)
ax3_td.set_title("c1   RWKV-7: T-Decomp (100% across all 25 cells)", fontsize=7.0, fontweight='bold', color='#1E40AF', pad=5)
ax3_td.set_xlabel("Context Length", fontsize=6.5, color='#1E293B', labelpad=2)
ax3_td.set_ylabel("Needle Depth", fontsize=6.5, color='#1E293B', labelpad=2)
ax3_td.tick_params(length=2, pad=2)

for i in range(len(depths)):
    for j in range(len(lengths)):
        ax3_td.text(j, i, f"{int(mat_td[i, j])}", ha='center', va='center', fontsize=5.8, fontweight='bold', color='#FFFFFF')

# Render Uniform INT4 heatmap with high contrast
im2 = ax3_u4.imshow(mat_u4, cmap='RdYlGn', vmin=0, vmax=100, aspect='auto')
ax3_u4.set_xticks(range(len(lengths)))
ax3_u4.set_xticklabels(horizons, fontsize=6.0)
ax3_u4.set_yticks(range(len(depths)))
ax3_u4.set_yticklabels(depth_labels, fontsize=6.0)
ax3_u4.set_title("c2   RWKV-7: Uniform INT4 (Collapse to 0% at 16K)", fontsize=7.0, fontweight='bold', color='#991B1B', pad=5)
ax3_u4.set_xlabel("Context Length", fontsize=6.5, color='#1E293B', labelpad=2)
ax3_u4.set_ylabel("Needle Depth", fontsize=6.5, color='#1E293B', labelpad=2)
ax3_u4.tick_params(length=2, pad=2)

for i in range(len(depths)):
    for j in range(len(lengths)):
        val = int(mat_u4[i, j])
        # High-contrast text: white on dark green or dark red; black on light yellow
        c_txt = '#FFFFFF' if (val >= 70 or val <= 30) else '#0F172A'
        ax3_u4.text(j, i, f"{val}", ha='center', va='center', fontsize=5.8, fontweight='bold', color=c_txt)

cbar_ax = fig.add_axes([0.93, 0.12, 0.015, 0.28])
cbar = fig.colorbar(im2, cax=cbar_ax)
cbar.set_label("Successes / 100", fontsize=6.0, fontweight='bold')
cbar.ax.tick_params(labelsize=5.5, length=2)

# Save deliverables
out_dir = str(Path(__file__).resolve().parent / 'regenerated')
os.makedirs(out_dir, exist_ok=True)
pdf_path = os.path.join(out_dir, 'fig4_long_context_niah_retrieval.pdf')
svg_path = os.path.join(out_dir, 'fig4_long_context_niah_retrieval.svg')
png_path = os.path.join(out_dir, 'fig4_long_context_niah_retrieval.png')
py_path = os.path.join(out_dir, 'fig4_long_context_niah_retrieval.py')

plt.savefig(pdf_path, format='pdf', bbox_inches='tight', pad_inches=0.04)
plt.savefig(svg_path, format='svg', bbox_inches='tight', pad_inches=0.04)
plt.savefig(png_path, format='png', dpi=300, bbox_inches='tight', pad_inches=0.04)
plt.close()

import shutil
# Archival self-copy omitted; this file is the retained source.
print("Updated Figure 4 generated successfully.")
