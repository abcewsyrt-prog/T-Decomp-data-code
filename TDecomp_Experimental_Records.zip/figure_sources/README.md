Figure plotting sources

Run each Python file from any working directory with numpy, pandas and matplotlib installed. Outputs go to regenerated/. All numerical inputs used by the retained scripts are included. The revised fig3 source changes method labels only. The mechanism raster and the author-supplied introduction image are retained as supplied, not reconstructed here.
