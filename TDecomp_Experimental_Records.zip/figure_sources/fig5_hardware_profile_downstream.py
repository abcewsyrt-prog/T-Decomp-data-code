from pathlib import Path
import os
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# =========================================================================
# Figure 5 | Aligned Downstream Benchmarks & Measured Hardware Profile
# Dimensions: 7.20 in x 3.20 in (Double Column Width)
# Font Hierarchy: Panel Titles 7.5pt bold, Axis Labels 6.8pt bold, Ticks 6.0pt, Numbers 5.2pt
# =========================================================================

fig = plt.figure(figsize=(7.20, 3.20), dpi=300)

plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial']
plt.rcParams['mathtext.fontset'] = 'dejavusans'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
plt.rcParams['axes.edgecolor'] = '#64748B'
plt.rcParams['axes.linewidth'] = 0.8

# Load data directly from raw source files
base_dir = str(Path(__file__).resolve().parent)
df_tasks = pd.read_csv(os.path.join(base_dir, '完整五任务结果.csv'))
df_packed = pd.read_csv(os.path.join(base_dir, '真实Packed质量与字节.csv'))

with open(os.path.join(base_dir, 'packed_probe.json')) as f:
    probe_data = json.load(f)

gs = fig.add_gridspec(1, 3, width_ratios=[1.25, 0.95, 0.95], wspace=0.36,
                      left=0.08, right=0.96, top=0.84, bottom=0.18)

# -------------------------------------------------------------
# Panel (a): Aligned Downstream Benchmarks (Token-Normalized Accuracy)
# -------------------------------------------------------------
ax1 = fig.add_subplot(gs[0, 0])
ax1.set_facecolor('#FFFFFF')
ax1.spines['top'].set_visible(False)
ax1.spines['right'].set_visible(False)

task_keys = ['arc_challenge', 'piqa', 'arc_easy', 'lambada', 'hellaswag']
task_names = ['ARC-C', 'PIQA', 'ARC-E', 'LAMB', 'Hella']
x_idx = np.arange(len(task_keys))
width = 0.19

# Extract accuracy_token_normalized directly from CSV
acc_ref = [100.0 * df_tasks[(df_tasks['task']==t) & (df_tasks['configuration']=='reference')]['accuracy_token_normalized'].values[0] for t in task_keys]
acc_u8  = [100.0 * df_tasks[(df_tasks['task']==t) & (df_tasks['configuration']=='uniform_int8')]['accuracy_token_normalized'].values[0] for t in task_keys]
acc_u4  = [100.0 * df_tasks[(df_tasks['task']==t) & (df_tasks['configuration']=='uniform_int4')]['accuracy_token_normalized'].values[0] for t in task_keys]
acc_td  = [100.0 * df_tasks[(df_tasks['task']==t) & (df_tasks['configuration']=='td_masked_ema_8_6')]['accuracy_token_normalized'].values[0] for t in task_keys]

base_y = 50.0
ax1.bar(x_idx - 1.5*width, np.array(acc_ref) - base_y, width, bottom=base_y, label='FP32 Ref', color='#334155', edgecolor='none')
ax1.bar(x_idx - 0.5*width, np.array(acc_u8)  - base_y, width, bottom=base_y, label='Uniform INT8', color='#059669', edgecolor='none')
ax1.bar(x_idx + 0.5*width, np.array(acc_u4)  - base_y, width, bottom=base_y, label='Uniform INT4', color='#EF4444', edgecolor='none')
ax1.bar(x_idx + 1.5*width, np.array(acc_td)  - base_y, width, bottom=base_y, label='T-Decomp', color='#2563EB', edgecolor='none')

ax1.set_xticks(x_idx)
ax1.set_xticklabels(task_names, fontsize=6.0, fontweight='medium')
ax1.set_ylim(base_y, 85.0)
ax1.set_ylabel("Normalized Accuracy (%)", fontsize=6.8, fontweight='bold', color='#1E293B', labelpad=3)
ax1.set_title("a   Aligned Downstream Tasks", fontsize=7.5, fontweight='bold', color='#0F172A', loc='left', pad=10)
ax1.tick_params(axis='both', labelsize=6.0, direction='out', length=2.5, pad=3)

ax1.legend(fontsize=4.8, loc='upper left', frameon=False, borderpad=0.1, handlelength=0.9)

# -------------------------------------------------------------
# Panel (b): Eager Decode Latency (packed_probe.json)
# -------------------------------------------------------------
ax2 = fig.add_subplot(gs[0, 1])
ax2.set_facecolor('#FFFFFF')
ax2.spines['top'].set_visible(False)
ax2.spines['right'].set_visible(False)

batches = ['B=1', 'B=16', 'B=64', 'B=128']
b_x = np.arange(len(batches))

lat_ref    = [probe_data['latency'][f'{b}/reference']['decode_ms_median'] for b in [1, 16, 64, 128]]
lat_update = [probe_data['latency'][f'{b}/td_update_only']['decode_ms_median'] for b in [1, 16, 64, 128]]
lat_packed = [probe_data['latency'][f'{b}/td_state_packed']['decode_ms_median'] for b in [1, 16, 64, 128]]

ax2.plot(b_x, lat_ref, 'D:', markersize=3.2, lw=1.1, color='#0F172A', label='FP32 Ref')
ax2.plot(b_x, lat_update, 's--', markersize=3.5, lw=1.2, color='#2563EB', label='TD Update Only')
ax2.plot(b_x, lat_packed, 'o-', markersize=4.0, lw=1.4, color='#DC2626', label='Physical Packed')

ax2.set_xticks(b_x)
ax2.set_xticklabels(batches, fontsize=6.0)
ax2.set_yscale('log')
ax2.set_ylim(20, 600)
ax2.set_ylabel("Step Decode Latency (ms)", fontsize=6.8, fontweight='bold', color='#1E293B', labelpad=2)
ax2.set_title("b   Eager Codec Decode Latency", fontsize=7.5, fontweight='bold', color='#0F172A', loc='left', pad=10)
ax2.tick_params(axis='both', labelsize=6.0, direction='out', length=2.5, pad=3)

# Legend placed in clean top-left space where y > 200ms
ax2.legend(fontsize=4.8, loc='upper left', frameon=False, borderpad=0.2, handlelength=1.1)

# Prototype note at lower right
ax2.text(0.96, 0.06, "Eager PyTorch Prototype",
         transform=ax2.transAxes, fontsize=4.8, color='#64748B', va='bottom', ha='right', style='italic')

# -------------------------------------------------------------
# Panel (c): Physical Packed Buffer Allocation (真实Packed质量与字节.csv)
# -------------------------------------------------------------
ax3 = fig.add_subplot(gs[0, 2])
ax3.set_facecolor('#FFFFFF')
ax3.spines['top'].set_visible(False)
ax3.spines['right'].set_visible(False)

buf_configs = ['FP16 State\nBaseline', 'Physical\nPacked Cache', 'FP32 State\nReference']
b_idx = np.arange(len(buf_configs))

# Convert bytes directly to MiB
bytes_fp16 = df_packed[df_packed['configuration']=='fp16_state']['buffer_bytes_min'].values[0] / (1024**2)
bytes_packed_min = df_packed[df_packed['configuration']=='td_state_packed']['buffer_bytes_min'].values[0] / (1024**2)
bytes_packed_max = df_packed[df_packed['configuration']=='td_state_packed']['buffer_bytes_max'].values[0] / (1024**2)
bytes_ref = df_packed[df_packed['configuration']=='reference']['buffer_bytes_min'].values[0] / (1024**2)

bar_h = [bytes_fp16, bytes_packed_max, bytes_ref]
colors_c = ['#64748B', '#059669', '#334155']

bars = ax3.bar(b_idx, bar_h, width=0.48, color=colors_c, edgecolor='none')

# Add packed breakdown annotation with compact width to avoid adjacent bar collision
ax3.text(1, bytes_packed_max + 0.8, f"{bytes_packed_min:.2f}–{bytes_packed_max:.2f}\nMiB",
         ha='center', va='bottom', fontsize=5.2, fontweight='bold', color='#059669')
ax3.text(0, bytes_fp16 + 0.8, f"{bytes_fp16:.2f}\nMiB", ha='center', va='bottom', fontsize=5.2, color='#64748B')
ax3.text(2, bytes_ref + 0.8, f"{bytes_ref:.2f}\nMiB", ha='center', va='bottom', fontsize=5.2, color='#334155')

ax3.set_xticks(b_idx)
ax3.set_xticklabels(buf_configs, fontsize=5.8)
ax3.set_ylim(0, 27)
ax3.set_ylabel("Persistent Cache Buffer (MiB)", fontsize=6.8, fontweight='bold', color='#1E293B', labelpad=2)
ax3.set_title("c   State Buffer Memory (4.8b payload)", fontsize=7.2, fontweight='bold', color='#0F172A', loc='left', pad=10)
ax3.tick_params(axis='both', labelsize=6.0, direction='out', length=2.5, pad=3)

# Save deliverables
out_dir = str(Path(__file__).resolve().parent / 'regenerated')
os.makedirs(out_dir, exist_ok=True)
pdf_path = os.path.join(out_dir, 'fig5_hardware_profile_downstream.pdf')
svg_path = os.path.join(out_dir, 'fig5_hardware_profile_downstream.svg')
png_path = os.path.join(out_dir, 'fig5_hardware_profile_downstream.png')
py_path = os.path.join(out_dir, 'fig5_hardware_profile_downstream.py')

plt.savefig(pdf_path, format='pdf', bbox_inches='tight', pad_inches=0.04)
plt.savefig(svg_path, format='svg', bbox_inches='tight', pad_inches=0.04)
plt.savefig(png_path, format='png', dpi=300, bbox_inches='tight', pad_inches=0.04)
plt.close()

import shutil
# Archival self-copy omitted; this file is the retained source.
print("Updated Figure 5 generated successfully.")
