from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

# =========================================================================
# Figure 2 | Temporal Error Dynamics & Cross-Model Quantization Targets
# Dimensions: 7.20 in x 3.20 in (Double Column Width)
# Font Hierarchy: Panel Titles 8.0pt bold, Axis Labels 7.2pt bold, Ticks 6.5pt, Text 5.8-6.2pt
# =========================================================================

fig = plt.figure(figsize=(7.20, 3.20), dpi=300)

plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial']
plt.rcParams['mathtext.fontset'] = 'dejavusans'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
plt.rcParams['axes.edgecolor'] = '#64748B'
plt.rcParams['axes.linewidth'] = 0.8

gs = fig.add_gridspec(1, 2, width_ratios=[1.0, 1.15], wspace=0.35,
                      left=0.09, right=0.96, top=0.86, bottom=0.16)

# -------------------------------------------------------------
# Panel (a): Theoretical Error Memory Length
# -------------------------------------------------------------
ax1 = fig.add_subplot(gs[0, 0])
ax1.set_facecolor('#FFFFFF')
ax1.spines['top'].set_visible(False)
ax1.spines['right'].set_visible(False)

w_vals = np.linspace(0.0, 0.95, 200)
H_vals = 1.0 / (1.0 - w_vals)

ax1.plot(w_vals, H_vals, color='#1E3A8A', lw=1.8)
ax1.fill_between(w_vals, 1.0, H_vals, color='#EFF6FF', alpha=0.6, edgecolor='none')

pts_w = [0.50, 0.80, 0.90, 0.95]
pts_H = [2.0, 5.0, 10.0, 20.0]
ax1.plot(pts_w, pts_H, 'o', color='#DC2626', markersize=3.5)

# Summary table placed in verified whitespace
ax1.text(0.42, 18.5, "Memory Horizon $H_c$:\n"
                     "• $w=0.50 \\to H=2.0$\n"
                     "• $w=0.80 \\to H=5.0$\n"
                     "• $w=0.90 \\to H=10.0$\n"
                     "• $w=0.95 \\to H=20.0$",
         fontsize=6.0, color='#0F172A', va='top', ha='left')

# Inset plot in top-left with generous right padding
ax_ins = ax1.inset_axes([0.10, 0.46, 0.28, 0.46])
ax_ins.set_facecolor('#FFFFFF')
ax_ins.spines['top'].set_visible(False)
ax_ins.spines['right'].set_visible(False)

t_steps = np.arange(0, 14)
for w_c, c_c, lbl in [(0.95, '#7C3AED', '0.95'), (0.85, '#DC2626', '0.85'), (0.60, '#D97706', '0.60'), (0.30, '#047857', '0.30')]:
    e_resp = (1.0 - w_c**t_steps) / (1.0 - w_c)
    ax_ins.plot(t_steps, e_resp, color=c_c, lw=1.1, label=lbl)

# Right margin padding: xlim up to 16 so curve ends at 13 safely away from right spine
ax_ins.set_xlim(0, 16)
ax_ins.set_ylim(0, 16)
ax_ins.set_xlabel('Steps', fontsize=5.2, labelpad=2)
ax_ins.set_title(r'Step Error $e_T/\delta$', fontsize=5.6, fontweight='bold', pad=3)
ax_ins.tick_params(labelsize=5.0, length=2, pad=1)
ax_ins.legend(fontsize=4.6, loc='upper left', bbox_to_anchor=(0.02, 0.98), frameon=False, borderpad=0.1, handlelength=0.8)

ax1.set_xlim(0.0, 1.0)
ax1.set_ylim(0.0, 22.0)
ax1.set_xlabel(r"State Transition Factor $w_c \in [0, 1)$", fontsize=7.2, fontweight='bold', color='#1E293B', labelpad=5)
ax1.set_ylabel("Error Memory Horizon $H_c = 1 / (1 - w_c)$", fontsize=7.2, fontweight='bold', color='#1E293B', labelpad=5)
ax1.set_title("a   Theoretical Recurrent Error Retention", fontsize=8.0, fontweight='bold', color='#0F172A', loc='left', pad=10)
ax1.tick_params(axis='both', labelsize=6.5, direction='out', length=3, pad=3)

# -------------------------------------------------------------
# Panel (b): Empirical Low-Bit Breakdown & Quantization Targets
# -------------------------------------------------------------
ax2 = fig.add_subplot(gs[0, 1])
ax2.set_facecolor('#FFFFFF')
ax2.spines['top'].set_visible(False)
ax2.spines['right'].set_visible(False)

bits = [8, 7, 6, 5, 4]
ppl_rwkv = [9.9469, 11.0824, 14.6849, 24.2444, 409.9539]
ppl_mamba = [13.0136, 16.2339, 42.7104, 554.3758, 9.57e13]
ppl_llama = [11.7438, 11.7438, 11.7506, 12.0100, 46.1511]

# Catastrophic Breakdown Zone shading for recurrent models (PPL > 50)
ax2.fill_between([8.6, 3.6], [50, 50], [1e15, 1e15], color='#FEE2E2', alpha=0.35, edgecolor='none', zorder=0)

# Explicit target identification in labels
ax2.plot(bits, ppl_mamba, marker='s', markersize=4.0, lw=1.5, color='#DC2626',
         label=r'Mamba-790M: SSM State $\mathbf{h}_t$', zorder=3)
ax2.plot(bits, ppl_rwkv, marker='o', markersize=4.0, lw=1.5, color='#2563EB',
         label=r'RWKV-7 2.9B: Lin-Attn State $\mathbf{S}_t$', zorder=3)
ax2.plot(bits, ppl_llama, marker='^', markersize=4.0, lw=1.3, color='#059669', linestyle='--',
         label='Llama-3.2 3B: Static KV-Cache (Control)', zorder=3)

# Place legend in clean upper-left whitespace (between PPL 500 and 1e5)
ax2.legend(fontsize=5.3, loc='upper left', bbox_to_anchor=(0.02, 0.98), frameon=False, borderpad=0.2, handlelength=1.1)

# Clear non-contradictory callout placed below legend
ax2.text(8.4, 2e7, "Recurrent Collapse (PPL > 50):\n"
                   "• Mamba 4b: $9.6 \\times 10^{13}$\n"
                   "• RWKV 4b: $410.0$\n"
                   "Static KV-Cache (Preserved):\n"
                   "• Llama-3.2 4b: $46.2$ (PPL < 50)",
         fontsize=5.4, color='#991B1B', va='top', ha='left')

ax2.set_yscale('log')
ax2.set_xlim(8.6, 3.6)
ax2.set_ylim(7.0, 1e15)
ax2.set_xlabel("Quantization Bit-Width", fontsize=7.2, fontweight='bold', color='#1E293B', labelpad=5)
ax2.set_ylabel("WikiText-2 Perplexity (Log Scale)", fontsize=7.2, fontweight='bold', color='#1E293B', labelpad=5)
ax2.set_title("b   Cross-Model Recurrent vs Static Sensitivity", fontsize=8.0, fontweight='bold', color='#0F172A', loc='left', pad=10)
ax2.tick_params(axis='both', labelsize=6.5, direction='out', length=3, pad=3)

# Save deliverables
out_dir = str(Path(__file__).resolve().parent / 'regenerated')
os.makedirs(out_dir, exist_ok=True)
pdf_path = os.path.join(out_dir, 'fig2_temporal_error_dynamics.pdf')
svg_path = os.path.join(out_dir, 'fig2_temporal_error_dynamics.svg')
png_path = os.path.join(out_dir, 'fig2_temporal_error_dynamics.png')
py_path = os.path.join(out_dir, 'fig2_temporal_error_dynamics.py')

plt.savefig(pdf_path, format='pdf', bbox_inches='tight', pad_inches=0.04)
plt.savefig(svg_path, format='svg', bbox_inches='tight', pad_inches=0.04)
plt.savefig(png_path, format='png', dpi=300, bbox_inches='tight', pad_inches=0.04)
plt.close()

import shutil
# Archival self-copy omitted; this file is the retained source.
print("Updated Figure 2 generated successfully.")
