from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

# =========================================================================
# Figure 3 | Pareto Frontiers & Protocol-Separated Synergy
# Dimensions: 7.20 in x 3.20 in (Double Column Width)
# Font Hierarchy: Panel Titles 8.0pt bold, Axis Labels 7.2pt bold, Ticks 6.5pt, Legends 5.4pt
# =========================================================================

fig = plt.figure(figsize=(7.20, 3.20), dpi=300)

plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial']
plt.rcParams['mathtext.fontset'] = 'dejavusans'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
plt.rcParams['axes.edgecolor'] = '#64748B'
plt.rcParams['axes.linewidth'] = 0.8

gs = fig.add_gridspec(1, 2, width_ratios=[1.05, 1.0], wspace=0.35,
                      left=0.09, right=0.96, top=0.84, bottom=0.16)

# -------------------------------------------------------------
# Panel (a): Mamba-790M: T-Decomp + Smooth Synergy
# -------------------------------------------------------------
ax1 = fig.add_subplot(gs[0, 0])
ax1.set_facecolor('#FFFFFF')
ax1.spines['top'].set_visible(False)
ax1.spines['right'].set_visible(False)

# Reference line in legend
ax1.plot([8.5, 4.0], [12.53, 12.53], color='#64748B', lw=0.9, linestyle=':', label='Ref FP32 (12.53)')

u_bits = [8.0, 7.0, 6.0, 5.0]
u_ppl = [13.0136, 16.2339, 42.7104, 554.3758]
ax1.plot(u_bits, u_ppl, marker='x', markersize=3.5, lw=1.2, color='#94A3B8', linestyle=':', label='Uniform Baseline')

# Smooth only (spatial)
ax1.plot([6.0, 5.0], [13.13, 15.87], '^', markersize=4.5, color='#7C3AED', label='Smooth (Spatial only)')

# T-Decomp only (temporal)
ax1.plot([6.84, 5.70], [18.06, 68.91], 'o--', markersize=4.0, lw=1.2, color='#0284C7', label='T-Decomp (Smooth off)')

# T-Decomp + Smooth (Co-design)
ax1.plot([6.85, 5.69], [12.83, 19.68], '*', markersize=7.5, color='#DC2626', label='T-Decomp (Smooth on)')

# Shaded synergy envelope
ax1.fill_between([6.85, 5.69], [12.83, 19.68], [18.06, 68.91], color='#FEE2E2', alpha=0.5, edgecolor='none')

# Annotations placed safely in open space below Ref line (12.53) with horizontal spacing
ax1.annotate('T-Decomp: 12.83', xy=(6.85, 12.83), xytext=(7.10, 8.2),
             fontsize=5.2, fontweight='bold', color='#DC2626', ha='center',
             arrowprops=dict(arrowstyle='->', color='#DC2626', lw=0.6, shrinkA=3, shrinkB=4))

ax1.annotate('T-Decomp: 19.68', xy=(5.69, 19.68), xytext=(5.30, 8.2),
             fontsize=5.2, fontweight='bold', color='#DC2626', ha='center',
             arrowprops=dict(arrowstyle='->', color='#DC2626', lw=0.6, shrinkA=3, shrinkB=4))

ax1.set_yscale('log')
ax1.set_xlim(8.6, 3.8)
ax1.set_ylim(6.0, 1200)
ax1.set_xlabel("Average Quantized Bits", fontsize=7.2, fontweight='bold', color='#1E293B', labelpad=5)
ax1.set_ylabel("Perplexity (Log Scale)", fontsize=7.2, fontweight='bold', color='#1E293B', labelpad=5)
ax1.set_title("a   Mamba-790M: Smooth Co-Design Synergy", fontsize=8.0, fontweight='bold', color='#0F172A', loc='left', pad=12)
ax1.tick_params(axis='both', labelsize=6.5, direction='out', length=3, pad=3)

ax1.legend(fontsize=5.2, loc='upper left', frameon=False, borderpad=0.2, handlelength=1.1)

# -------------------------------------------------------------
# Panel (b): RWKV-7 2.9B Protocol-Separated Operating Points
# -------------------------------------------------------------
ax2 = fig.add_subplot(gs[0, 1])
ax2.set_facecolor('#FFFFFF')
ax2.spines['top'].set_visible(False)
ax2.spines['right'].set_visible(False)

# Reference in legend
ax2.plot([8.5, 4.0], [9.7878, 9.7878], color='#64748B', lw=0.9, linestyle=':', label='Ref FP32 (9.79)')

rwkv_u_bits = [8.0, 7.0, 6.0, 5.0, 4.0]
rwkv_u_ppl = [9.9469, 11.0824, 14.6849, 24.2444, 409.9539]
ax2.plot(rwkv_u_bits, rwkv_u_ppl, marker='x', markersize=3.5, lw=1.2, color='#94A3B8', linestyle=':', label='Uniform Baseline')

# Main threshold sweep curve
sw_x = [8.000, 7.766, 7.701, 7.524]
sw_y = [9.8456, 9.8862, 9.9220, 9.9613]
ax2.plot(sw_x, sw_y, 'o-', markersize=3.5, lw=1.3, color='#1D4ED8', label='TD Threshold Sweep')

# Distinct protocols/compensations plotted as separate points
ax2.plot([7.622], [9.9255], 'D', markersize=4.5, color='#059669', label='TD Immediate (7.62b @ 9.93)')
ax2.plot([7.622], [9.9544], 's', markersize=4.5, color='#D97706', label='TD 1-Step Delay (7.62b @ 9.95)')
ax2.plot([7.250], [10.6022], '^', markersize=4.5, color='#7C3AED', label='Historical Point (7.25b @ 10.60)')
ax2.plot([5.500], [11.4045], '*', markersize=7.0, color='#DC2626', label='TD Aggressive (5.50b @ 11.40)')

# Callout for aggressive point in open space below Ref line (9.79)
ax2.annotate('Aggressive: 11.40', xy=(5.50, 11.40), xytext=(5.50, 7.5),
             fontsize=5.2, fontweight='bold', color='#DC2626', ha='center',
             arrowprops=dict(arrowstyle='->', color='#DC2626', lw=0.6, shrinkA=3, shrinkB=4))

ax2.set_yscale('log')
ax2.set_xlim(8.6, 3.8)
ax2.set_ylim(5.8, 550)
ax2.set_xlabel("Average Quantized Bits", fontsize=7.2, fontweight='bold', color='#1E293B', labelpad=5)
ax2.set_ylabel("Perplexity (Log Scale)", fontsize=7.2, fontweight='bold', color='#1E293B', labelpad=5)
ax2.set_title("b   RWKV-7 2.9B: Protocol-Separated Points", fontsize=8.0, fontweight='bold', color='#0F172A', loc='left', pad=12)
ax2.tick_params(axis='both', labelsize=6.5, direction='out', length=3, pad=3)

ax2.legend(fontsize=4.9, loc='upper left', frameon=False, borderpad=0.2, handlelength=1.1)

# Save deliverables
out_dir = str(Path(__file__).resolve().parent / 'regenerated')
os.makedirs(out_dir, exist_ok=True)
pdf_path = os.path.join(out_dir, 'fig3_pareto_smooth_synergy.pdf')
svg_path = os.path.join(out_dir, 'fig3_pareto_smooth_synergy.svg')
png_path = os.path.join(out_dir, 'fig3_pareto_smooth_synergy.png')
py_path = os.path.join(out_dir, 'fig3_pareto_smooth_synergy.py')

plt.savefig(pdf_path, format='pdf', bbox_inches='tight', pad_inches=0.04)
plt.savefig(svg_path, format='svg', bbox_inches='tight', pad_inches=0.04)
plt.savefig(png_path, format='png', dpi=300, bbox_inches='tight', pad_inches=0.04)
plt.close()

import shutil

print("Updated Figure 3 generated successfully.")
