from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

# =========================================================================
# Figure 6 | Historical Component Ablations & Sequence Sampling Stability
# Dimensions: 7.20 in x 3.20 in (Double Column Width)
# Font Hierarchy: Panel Titles 7.5pt bold, Axis Labels 6.8pt bold, Ticks 6.0pt, Numbers 5.4pt
# =========================================================================

fig = plt.figure(figsize=(7.20, 3.20), dpi=300)

plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial']
plt.rcParams['mathtext.fontset'] = 'dejavusans'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
plt.rcParams['axes.edgecolor'] = '#64748B'
plt.rcParams['axes.linewidth'] = 0.8

gs = fig.add_gridspec(1, 2, width_ratios=[1.18, 1.0], wspace=0.34,
                      left=0.10, right=0.96, top=0.84, bottom=0.16)

# -------------------------------------------------------------
# Panel (a): Architectural Component Ablations (Historical Immediate Protocol)
# -------------------------------------------------------------
ax1 = fig.add_subplot(gs[0, 0])
ax1.set_facecolor('#FFFFFF')
ax1.spines['top'].set_visible(False)
ax1.spines['right'].set_visible(False)

components = ['Full Method', 'w/o Control Prot', r'w/o Routing ($m_t$)', r'w/o Residual ($r_t$)', r'w/o Energy ($E_t$)']
y_idx = np.arange(len(components))
height = 0.35

ppl_rwkv = [9.93, 9.90, 14.68, 10.06, 10.09]
ppl_mamba = [18.06, 133.70, 42.71, 22.84, 19.83]

ax1.barh(y_idx - height/2, ppl_mamba, height, label='Mamba-790M (SSM)', color='#EF4444', edgecolor='none')
ax1.barh(y_idx + height/2, ppl_rwkv,  height, label='RWKV-7 2.9B (Lin-Attn)', color='#2563EB', edgecolor='none')

ax1.set_xscale('log')
ax1.set_xlim(8.0, 220.0)
ax1.set_yticks(y_idx)
ax1.set_yticklabels(components, fontsize=6.0)
ax1.invert_yaxis()
ax1.set_xlabel("Perplexity (Log Scale)", fontsize=6.8, fontweight='bold', color='#1E293B', labelpad=3)
ax1.set_title("a   Component Ablations (Historical Protocol)", fontsize=7.5, fontweight='bold', color='#0F172A', loc='left', pad=10)
ax1.tick_params(axis='both', labelsize=6.0, direction='out', length=2.5, pad=3)

ax1.legend(fontsize=5.2, loc='lower right', frameon=False, borderpad=0.2, handlelength=1.0)

# -------------------------------------------------------------
# Panel (b): 3-Fold Cross-Validation Variance on Mamba-790M (Historical Slices)
# -------------------------------------------------------------
ax2 = fig.add_subplot(gs[0, 1])
ax2.set_facecolor('#FFFFFF')
ax2.spines['top'].set_visible(False)
ax2.spines['right'].set_visible(False)

schemes = ['TD Bal', 'TD Agg', 'INT6', 'INT5']
s_x = np.arange(len(schemes))
means = [19.45, 73.57, 44.60, 535.20]
stds  = [0.20, 1.70, 0.98, 58.80]
colors = ['#2563EB', '#D97706', '#64748B', '#EF4444']

ax2.bar(s_x, means, yerr=stds, capsize=3, width=0.45, color=colors, edgecolor='none',
        error_kw=dict(ecolor='#0F172A', elinewidth=0.8, capthick=0.8))

for i in range(len(schemes)):
    top_y = means[i] + stds[i]
    c = colors[i]
    if i == 0:
        ax2.text(i, top_y * 1.35, f"{means[i]:.2f}\n(std={stds[i]:.2f})", ha='center', va='bottom', fontsize=5.2, fontweight='bold', color=c)
    elif i == 3:
        ax2.text(i, top_y * 1.25, f"{means[i]:.1f}\n(std={stds[i]:.1f})", ha='center', va='bottom', fontsize=5.2, color=c)
    else:
        ax2.text(i, top_y * 1.30, f"{means[i]:.2f}\n(std={stds[i]:.1f})", ha='center', va='bottom', fontsize=5.2, color=c)

ax2.set_yscale('log')
ax2.set_xticks(s_x)
ax2.set_xticklabels(schemes, fontsize=6.0)
ax2.set_ylim(10, 1800)
ax2.set_ylabel("3-Fold PPL (Mean ± Std)", fontsize=6.8, fontweight='bold', color='#1E293B', labelpad=3)
ax2.set_title("b   Mamba-790M 3-Fold Evaluation (Historical Slices)", fontsize=7.5, fontweight='bold', color='#0F172A', loc='left', pad=10)
ax2.tick_params(axis='both', labelsize=6.0, direction='out', length=2.5, pad=3)

# Deliverable outputs
out_dir = str(Path(__file__).resolve().parent / 'regenerated')
os.makedirs(out_dir, exist_ok=True)
pdf_path = os.path.join(out_dir, 'fig6_ablation_and_stability.pdf')
svg_path = os.path.join(out_dir, 'fig6_ablation_and_stability.svg')
png_path = os.path.join(out_dir, 'fig6_ablation_and_stability.png')
py_path = os.path.join(out_dir, 'fig6_ablation_and_stability.py')

plt.savefig(pdf_path, format='pdf', bbox_inches='tight', pad_inches=0.04)
plt.savefig(svg_path, format='svg', bbox_inches='tight', pad_inches=0.04)
plt.savefig(png_path, format='png', dpi=300, bbox_inches='tight', pad_inches=0.04)
plt.close()

import shutil
# Archival self-copy omitted; this file is the retained source.
print("Figure 6 successfully generated and saved.")
