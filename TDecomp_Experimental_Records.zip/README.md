# Supplementary Material: Experimental Data and Reproducibility Records for T-Decomp

This package accompanies the Neurocomputing manuscript “T-Decomp: Time-Aware State Decoupling for Mixed-Precision Quantization of Recurrent Language Models.” Prepared 2026-11-02.

## Contents and evidence scope
- `01_core`: fixed-quantizer native recurrent-controller and loaded 7.2B experiments, per-token NLL, controller tests, and available execution snapshots.
- `02_tasks`: five complete downstream tasks, four configurations each; item IDs, gold choices, correctness, option likelihoods, and task summaries. Sampling unit is the question, not each answer token. LAMBADA uses its complete-word criterion.
- `03_retrieval`: final 100-cell grid, 100 cases per cell, lengths 1024/2048/4096/8192/16384 and five insertion depths. Records contain generated target/answer and exact-match flags. There are 10,000 model-case evaluations from 2,500 paired prompts. INT6 was not measured; no partial INT6 records are included.
- `04_document_traces`, `05_dense_traces`: document-level summaries and token/step/layer traces. Rows within a document are dependent observations; do not treat them as independent subjects.
- `06_routing_mamba_crosscorpus`: matched routing controls and random seeds, Mamba mechanism tests, and separate cross-corpus document traces.
- `07_packed_quality`: five configurations, 40 windows and 10,240 scored tokens per configuration, physical buffer accounting and codec/backend source. Packed and numerical-state token NLL agree exactly in this record. Numerical quantization and physical packing are distinct interventions.
- `08_packed_timing`: exclusive complete-model decoding timings, raw samples, identity checks and byte accounting. A 512-token probe quality record is not substituted for the 10,240-token quality evaluation. The packed prototype is slower and uses more total buffers than the plain FP16-state reference.
- `09_official_ptq`: completed Quamba W4A16, native comparison, identity/diagnostic records and scripts. A8 diagnostic failures are not valid comparative quality measurements.
- `10_runner_preparation`: local preparation/launcher source, distinguished from execution snapshots. A preparation wrapper is not itself proof that a run was executed.
- `11_extended_controls`: earlier executed RWKV extended/feedback controls; their interface and corpus protocol differ from the native-controller experiments. Pilot records remain labeled as pilots.
- `12_source_reported`: table cells retained from the current manuscript, including source-reported historical Smooth values and separately executed comparisons. These table cells are not themselves raw execution logs. No missing historical per-token data or run configuration has been invented.
- `summary_tables`, `figure_sources`: exported tables and final plotting code/inputs. Some historical plot points are embedded in plotting scripts. The final manuscript determines the intended table/figure order.

## Recomputing the main record checks
Run `python3 validate_records.py`. It checks 20 complete task groups, their item counts/correctness, 100 complete retrieval cells, packed quality token counts/PPL, and recorded decode samples. No GPU or model download is needed for these checks. `validation_report.json` records the tested checks. SHA-256 values in `manifest.csv` identify the sanitized distributable files.

## Re-running model inference
Execution snapshots retain the numerical controller implementations and recorded protocols. Model checkpoints, tokenizers, benchmark corpora, third-party environments and model-library code are not bundled. Obtain these from their respective rights holders and install the dependencies recorded in result metadata. Replace `/REDACTED_PATH/...` with authorized local model, data and output paths; preserve the checkpoint/input SHA-256 values when claiming an exact reproduction. The available snapshots are not advertised as a single turnkey environment. Plot scripts require NumPy, pandas and Matplotlib; their inputs are included.

## Data handling
Machine-specific paths, network addresses and contact/authentication metadata were removed or generalized. Numerical scores, item/token identifiers, trial counts and input hashes were preserved. No credentials, private project title/identifier, checkpoint weights, or raw benchmark corpus files are intentionally distributed. Each benchmark remains subject to its original access and licensing conditions. This package is distributed as a public experimental-record archive. No DOI or new software license is claimed. Original local execution records remain unchanged.

## Interpretation
Nominal payload bits do not include auxiliary state. Residual dtype, scales, masks, alignment and buffers must be counted separately. FP16-rounded values in an FP32 tensor do not constitute FP16 physical storage. Historical Smooth settings remain unchanged at the author's request and are not reassigned to the newly executed Smooth-off protocols. No new significance tests, p-values or equal-budget conclusions are introduced by this package.
