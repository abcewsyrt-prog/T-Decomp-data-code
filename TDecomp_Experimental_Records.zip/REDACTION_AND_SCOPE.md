# Distribution preparation

The distributable files are derived copies. Numerical measurements and experimental identifiers were retained. Machine-specific paths were replaced by neutral `/REDACTED_PATH/...` or `/REDACTED_ROOT` locations; email/network addresses and authentication metadata were removed. Original environment inventory, SSH transport/credential helpers and server-control logs were excluded. Model weights, raw public-corpus text and confidential project identifiers are not included. Quantization-granularity sweep files were excluded. No original source file was changed.

The package includes completed experiment outputs plus clearly separated earlier controls and historical table cells. It does not provide missing historical Smooth execution logs, a complete original model environment, or a new software license. Code snapshots may depend on third-party libraries and their original licenses. Refer to each retained protocol and input digest before reproducing results.
