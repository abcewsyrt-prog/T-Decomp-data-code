import os,sys,re,json,csv,math,hashlib,time
from pathlib import Path
os.environ['HF_HUB_OFFLINE']='1';os.environ['TOKENIZERS_PARALLELISM']='false'
sys.path[:0]=['/REDACTED_ROOT','/REDACTED_PATH/tsq']
import torch,torch.nn.functional as F
from tsq.common import load_rwkv7
from tsq.rwkv7_rec import install
from core_controller import Ctrl
ROOT=Path('/REDACTED_PATH/tdecomp_nc_20261028');OUT=ROOT/'longalpaca_document_traces.json'
class TraceCtrl(Ctrl):
 def __init__(self):super().__init__();self.trace_steps={};self.reference={};self.capture_reference=False;self.rows=[];self.selected=set()
 def reset(self):
  super().reset();self.trace_steps={};self.rows=[]
 def step(self,lid,S,w,ab,vk,B,H,N,L,v=None,k=None):
  t=self.trace_steps.get(lid,0);self.trace_steps[lid]=t+1
  before=self.hist.get(lid,{}).get('bit_elements',{}).copy()
  out,read=super().step(lid,S,w,ab,vk,B,H,N,L,v,k)
  if lid in self.selected and t in self.sample_positions:
   state=out.detach().float().cpu()
   if self.capture_reference:self.reference[(lid,t)]=state
   else:
    ref=self.reference[(lid,t)];error=float(torch.linalg.vector_norm(state-ref)/torch.linalg.vector_norm(ref).clamp_min(1e-12));res=self.res.get(lid);hist=self.hist.get(lid,{}).get('bit_elements',{});counts={k:n-before.get(k,0) for k,n in hist.items()};den=sum(counts.values());bits=sum(int(k)*n for k,n in counts.items())/den if den else 32.
    self.rows.append(dict(layer=lid,state_step=t,score_token_position=t+1,lag=1,state_relative_frobenius_error=error,residual_norm=float(res.norm()) if res is not None else 0.,actual_update_bits=bits))
  return out,read

def save(x):
 p=OUT.with_suffix('.tmp');p.write_text(json.dumps(x,indent=2,allow_nan=False));p.replace(OUT)
def main():
 import fcntl
 _task_lock=open(str(OUT)+'.lock','a');fcntl.flock(_task_lock,fcntl.LOCK_EX)
 if os.path.exists(OUT) and json.load(open(OUT)).get('status')=='completed':
  print('Existing completed result retained',flush=True);return
 torch.set_num_threads(4);torch.set_num_interop_threads(2);torch.manual_seed(42);torch.backends.cuda.matmul.allow_tf32=False
 model,tok=load_rwkv7('/REDACTED_PATH/rwkv7_2b9',dtype=torch.float32);c=TraceCtrl();L,H,N=install(model,c);c.selected={0,L//2,L-1}
 corpus=Path('/REDACTED_PATH/LongAlpaca-12k_.csv');hasher=hashlib.sha256()
 with corpus.open('rb') as stream:
  for chunk in iter(lambda:stream.read(1048576),b''):hasher.update(chunk)
 source_sha=hasher.hexdigest();docs=[];csv.field_size_limit(100000000)
 with corpus.open(newline='') as stream:
  for i,row in enumerate(csv.DictReader(stream)):
   text=row.get('input','').strip() or row.get('instruction','')
   if 'The paper begins.' in text:text=text.split('The paper begins.',1)[1]
   if 'The paper ends.' in text:text=text.split('The paper ends.',1)[0]
   if len(text)<1500:continue
   ids=tok(text[:8000],add_special_tokens=False)['input_ids'][:1024]
   if len(ids)<128:continue
   docs.append(dict(id=i,ids=ids,text_sha256=hashlib.sha256(text.encode()).hexdigest()))
   if len(docs)==20:break
 assert len(docs)>=2
 result=json.loads(OUT.read_text()) if OUT.exists() else dict(status='running',protocol=dict(dataset='LongAlpaca local CSV paper contexts; not claimed unseen in pretraining',corpus_sha256=source_sha,selection='first 20 eligible CSV contexts with >=128 tokens; first 8000 characters tokenized and capped at1024; paper markers stripped when present; output answers excluded; no performance selection',documents=len(docs),layers=sorted(c.selected),warmup=0,reset='per document and configuration',input='teacher-forced matched tokens; full-model reference states, not a random recurrence',state_step='zero-based input position t; output predicts target token t+1',independent_unit='document',dtype='FP32; FP16-rounded residual values in FP32 buffers; fixed native value-row quantizer'),documents={})
 for doc in docs:
  key=str(doc['id'])
  if key in result['documents']:continue
  x=torch.tensor([doc['ids']],device='cuda');c.sample_positions={p for p in [31,63,127,255,511,1023] if p<len(doc['ids'])-1};c.reference={};c.method='none';c.reset();c.schedules.clear();c.capture_reference=True
  with torch.inference_mode():logits=model(x,use_cache=False).logits[0,:-1];ref_loss=F.cross_entropy(logits,x[0,1:],reduction='none').cpu()
  del logits;c.capture_reference=False;records=[];summary={}
  for name,method,bits in [('uniform8','uniform8',8),('uniform4','uniform4',4),('masked_ema_8_6','balanced',8)]:
   c.method=method;c.bits=bits;c.reset();c.schedules.clear()
   with torch.inference_mode():logits=model(x,use_cache=False).logits[0,:-1];loss=F.cross_entropy(logits,x[0,1:],reduction='none').cpu()
   del logits
   for row in c.rows:
    t=row['state_step'];records.append(dict(doc_id=doc['id'],configuration=name,**row,reference_nll=float(ref_loss[t]),variant_nll=float(loss[t]),excess_nll=float(loss[t]-ref_loss[t])))
   summary[name]=dict(tokens=len(loss),reference_mean_nll=float(ref_loss.double().mean()),variant_mean_nll=float(loss.double().mean()),mean_excess_nll=float((loss-ref_loss).double().mean()))
  file=ROOT/f'longalpaca_doc_trace_{doc["id"]}.csv'
  with file.open('w') as f:w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
  result['documents'][key]=dict(tokens=len(doc['ids']),text_sha256=doc['text_sha256'],input_sha256=hashlib.sha256(x.cpu().numpy().tobytes()).hexdigest(),records=file.name,rows=len(records),summary=summary);save(result);print('document_completed',key,len(doc['ids']),flush=True)
  del x,loss,ref_loss;c.reference={};torch.cuda.empty_cache()
 result['status']='completed';save(result)
if __name__=='__main__':main()
