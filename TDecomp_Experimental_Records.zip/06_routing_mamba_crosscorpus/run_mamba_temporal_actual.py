import os,sys,time,json,math,traceback,hashlib
os.environ['HF_HUB_OFFLINE']='1';os.environ['HF_DATASETS_OFFLINE']='1';os.environ['TOKENIZERS_PARALLELISM']='false'
sys.path[:0]=['/REDACTED_ROOT','/REDACTED_PATH/tsq']
import torch
import torch.nn.functional as F
from transformers import AutoModelForCausalLM,AutoTokenizer
from transformers.models.mamba import modeling_mamba as MM
import inspect,textwrap,types
ROOT='/REDACTED_PATH/tdecomp_nc_20261028';OUT=ROOT+'/mamba_temporal_mechanism.json'
def save(r):
    with open(OUT+'.tmp','w') as f:json.dump(r,f,indent=2,allow_nan=False)
    os.replace(OUT+'.tmp',OUT)
class Ctrl:
 def __init__(self):self.method='none';self.batch_index=0;self.schedules={};self.calls=0;self.reset()
 def reset(self):self.res={};self.threshold={};self.energy={};self.steps={};self.hist={};self.calls=0
 def __call__(self,lid,prev,w,u):
  self.calls+=1
  if self.method=='none':return w*prev+u
  B,D,N=u.shape;w=w.float();u=u.float();step=self.steps.get(lid,0);self.steps[lid]=step+1
  if self.method=='control8':
   sc=w.abs().amax(-1,keepdim=True).clamp_min(1e-12)/127;w=(w/sc).round().clamp(-127,127)*sc
  if self.method in ('uniform8','uniform6','uniform4'):
   bits=torch.full_like(w,int(self.method[-1]),dtype=torch.int64);mask=torch.zeros_like(w,dtype=torch.bool)
  else:
   threshold=self.threshold.get(lid,torch.full((B,1,1),.85,device=u.device));mask=w>=threshold
   if self.method=='no_routing':mask=torch.zeros_like(mask)
   energy=(w*(~mask)).square().sum((1,2),keepdim=True).sqrt();prior=self.energy.get(lid,energy);promote=energy>1.5*prior
   if self.method=='no_energy':promote=torch.zeros_like(promote)
   self.threshold[lid]=.99*threshold+.01*w.mean((1,2),keepdim=True);self.energy[lid]=.99*prior+.01*energy
   if self.method=='balanced':self.schedules[(self.batch_index,lid,step)]=(mask.reshape(B,-1).sum(-1,keepdim=True).clone(),promote.clone())
   if self.method in ('random','inverted'):
    count,promote=self.schedules[(self.batch_index,lid,step)]
    if self.method=='random':
     g=torch.Generator(device=u.device);g.manual_seed(42+lid*100000+step);score=torch.rand(B,D*N,device=u.device,generator=g)
    else:score=-w.reshape(B,-1)
    order=score.argsort(dim=-1,descending=True,stable=True);rank=torch.empty_like(order);rank.scatter_(1,order,torch.arange(D*N,device=u.device).expand_as(order));mask=(rank<count).reshape_as(w)
   bits=torch.where(mask,8,torch.where(promote,8,6))
  qm=2.**(bits-1)-1;scale=u.abs().amax(-1,keepdim=True).clamp_min(1e-12)/qm;q=(u/scale).round().clamp(-qm,qm)*scale
  old=self.res.get(lid,torch.zeros_like(u));correction=w*old*mask if self.method not in ('no_feedback','uniform8','uniform6','uniform4') else 0
  self.res[lid]=((u-q)*(~mask)).half()
  h=self.hist.setdefault(lid,{'elements':0,'bit_elements':{}});h['elements']+=u.numel()
  for bi in (4,6,8):h['bit_elements'][str(bi)]=h['bit_elements'].get(str(bi),0)+int((bits==bi).sum())
  return w*prev+q+correction

def install_mamba(model,c):
 src=inspect.getsource(MM.MambaMixer.slow_forward);lines=src.splitlines();hit=0
 for i,line in enumerate(lines):
  if line.strip().startswith('ssm_state = discrete_A') and 'deltaB_u' in line:
   lines[i]=' '* (len(line)-len(line.lstrip()))+'ssm_state = _TEMP_CTRL(self.layer_idx, ssm_state, discrete_A[:, :, i, :], deltaB_u[:, :, i, :])';hit+=1
 assert hit==1,hit
 ns=dict(vars(MM));ns['_TEMP_CTRL']=c;exec(textwrap.dedent('\n'.join(lines)),ns)
 for m in model.modules():
  if isinstance(m,MM.MambaMixer):m.slow_forward=types.MethodType(ns['slow_forward'],m)
 return hit

def main():
    import fcntl
    _task_lock=open(str(OUT)+'.lock','a');fcntl.flock(_task_lock,fcntl.LOCK_EX)
    if os.path.exists(OUT) and json.load(open(OUT)).get('status')=='completed':
     print('Existing completed result retained',flush=True);return
    torch.set_num_threads(4);torch.set_num_interop_threads(2);torch.manual_seed(42);torch.backends.cuda.matmul.allow_tf32=False
    r=dict(status='loading',scope='loaded_Mamba790m_temporal_increment_mechanism_not_granularity_study',not_full_benchmark=True,results={},torch=torch.__version__,gpu=torch.cuda.get_device_name(),started=time.time());save(r)
    # Reference and patched versions both use the same native slow path; only state rounding is inserted.
    if hasattr(MM,'is_fast_path_available'):MM.is_fast_path_available=False
    model=AutoModelForCausalLM.from_pretrained('/REDACTED_PATH/mamba790',local_files_only=True,dtype=torch.float32).cuda().eval();print('model_loaded',flush=True)
    tok=AutoTokenizer.from_pretrained('/REDACTED_PATH/gpt-neox-20b-tokenizer',local_files_only=True)
    text=open('/REDACTED_PATH/wiki.test.tokens').read()[:200000];ids=tok(text,add_special_tokens=False,return_tensors='pt').input_ids[0]
    ids=ids[4096:]
    print('tokenized after pilot offset',len(ids),flush=True)
    r.update(parameters=sum(p.numel() for p in model.parameters()),dtype='float32',data_sha256=hashlib.sha256(text.encode()).hexdigest(),corpus_slice_tokens=len(ids))
    x=ids[:32][None].cuda()
    with torch.inference_mode():a=model(x,use_cache=False).logits.float().cpu()
    c=Ctrl();hit=install_mamba(model,c)
    with torch.inference_mode():b=model(x,use_cache=False).logits.float().cpu()
    err=(a-b).abs();r['identity']=dict(max_abs_logits=float(err.max()),argmax_agreement=float((a.argmax(-1)==b.argmax(-1)).float().mean()),hook_hits=hit,controller_calls=c.calls)
    if float(err.max())>1e-5 or not c.calls:r['status']='identity_failed';save(r);return
    r['status']='running';save(r);del a,b
    length=512;stride=256;nw=40;xs=torch.stack([ids[i*stride:i*stride+length] for i in range(nw)]).cuda();ys=xs[:,1:]
    r['protocol']=dict(split='test',length=length,stride=stride,windows=nw,scored_tokens=nw*stride,score='last 256 targets/window; token offset 4096',seed=42,intervention='native deltaB_u increment quantization; masked decay-weighted previous transient residual; physical FP16 residual; fixed per-inner-channel state-axis scale',control='native_float32 except control8 ablation',input_sha256=hashlib.sha256(xs.cpu().numpy().tobytes()).hexdigest())
    specs=[('reference','none'),('uniform8','uniform8'),('uniform6','uniform6'),('uniform4','uniform4'),('masked_ema_8_6','balanced'),('no_energy','no_energy'),('no_feedback','no_feedback'),('control8','control8'),('random_matched','random'),('inverted_matched','inverted')]
    for name,method in specs:
        c.method=method;c.reset();torch.cuda.synchronize();t0=time.perf_counter()
        all_scores=[];all_hist=[]
        for begin in range(0,nw,8):
            c.batch_index=begin;c.reset()
            with torch.inference_mode():
                logits=model(xs[begin:begin+8],use_cache=False).logits[:,:-1].float()
                loss=F.cross_entropy(logits.reshape(-1,logits.size(-1)),ys[begin:begin+8].reshape(-1),reduction='none').reshape(min(8,nw-begin),length-1)
                all_scores.append(loss[:,-stride:].cpu());all_hist.append(c.hist)
            del logits,loss
        scored=torch.cat(all_scores);total=float(scored.sum());mean=total/scored.numel();values=scored.tolist()
        torch.cuda.synchronize();elapsed=time.perf_counter()-t0
        if not c.calls:raise RuntimeError('No quantization hook calls')
        row=dict(ppl=math.exp(mean) if mean<709 else None,mean_nll=mean,nll_sum=total,scored_tokens=scored.numel(),allocation_histograms=all_hist,method=method,controller_calls_last_batch=c.calls,elapsed_seconds=elapsed,window_mean_nll=scored.mean(1).cpu().tolist())
        r['results'][name]=row
        with open(ROOT+'/mamba_temporal_'+name+'_token_nll.json','w') as f:json.dump(values,f)
        save(r);print(name,json.dumps(row),flush=True);del scored;torch.cuda.empty_cache()
    r['status']='completed';r['finished']=time.time();save(r)
if __name__=='__main__':
    try:main()
    except Exception:
        with open(ROOT+'/mamba_temporal_error.txt','w') as f:f.write(traceback.format_exc())
        raise
