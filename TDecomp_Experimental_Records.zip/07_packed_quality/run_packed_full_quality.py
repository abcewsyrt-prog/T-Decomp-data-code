import os,sys,json,time,math,hashlib,fcntl
from pathlib import Path
os.environ['HF_HUB_OFFLINE']='1';sys.path[:0]=['/REDACTED_ROOT','/REDACTED_PATH/tsq']
import torch,torch.nn.functional as F
from tsq.common import load_rwkv7
from tsq.rwkv7_rec import install
from packed_state_backend import DeploymentCtrl,ModelState,EncodedState
R=Path('/REDACTED_PATH/tdecomp_nc_20261028');OUT=R/'packed_full_quality.json'
def save(r):p=OUT.with_suffix('.tmp');p.write_text(json.dumps(r,indent=2,allow_nan=False));p.replace(OUT)
def main():
 lock=open(str(OUT)+'.lock','a');fcntl.flock(lock,fcntl.LOCK_EX)
 result=json.loads(OUT.read_text()) if OUT.exists() else dict(status='running',results={})
 if result['status']=='completed' and 'fp16_state' in result['results']:return
 torch.set_num_threads(4);torch.set_num_interop_threads(2);torch.manual_seed(42);torch.backends.cuda.matmul.allow_tf32=False
 result.update(status='loading_model');save(result)
 model,tok=load_rwkv7('/REDACTED_PATH/rwkv7_2b9',dtype=torch.float32);c=DeploymentCtrl();install(model,c)
 token_path=Path('/REDACTED_PATH/wiki.test.ids.pt');all_ids=torch.load(token_path,weights_only=True);assert all_ids.ndim==1;ids=all_ids[4096:].cuda()
 result.update(protocol=dict(scope='actual packed WKV write-back with physical FP16 residual; extra intervention beyond update-only main',model_dtype='FP32',windows=40,stride=256,input_tokens=512,score='target positions257..512 inclusive; prefix257 then255 one-token cached calls;256 targets/window',scored_targets_per_config=10240,source_token_cache=str(token_path),source_token_cache_sha256=hashlib.sha256(token_path.read_bytes()).hexdigest(),input_sha256=hashlib.sha256(ids[:10497].cpu().numpy().tobytes()).hexdigest(),timing='not measured; concurrent quality only'),status='running');save(result)
 try:
  for name,method,mode in [('reference','none','reference'),('fp16_state','none','fp16_state'),('td_update_only','balanced','reference'),('td_state_fake','balanced','state_fake'),('td_state_packed','balanced','state_packed')]:
   result['current']=name;v=result['results'].setdefault(name,dict(windows={},status='running'));save(result);c.method=method
   for j in range(40):
    if str(j) in v['windows']:continue
    c.reset();state=ModelState(mode,c);x=ids[j*256:j*256+513][None];assert x.shape[1]==513
    with torch.inference_mode():
     out=model(x[:,:257],state=state,use_cache=True,logits_to_keep=1);loss=[]
     for t in range(257,513):
      value=float(F.cross_entropy(out.logits[:,-1].float(),x[:,t]));assert math.isfinite(value);loss.append(value)
      if t<512:out=model(x[:,t:t+1],state=state,use_cache=True,logits_to_keep=1)
    v['windows'][str(j)]=dict(token_nll=loss,input_sha256=hashlib.sha256(x.cpu().numpy().tobytes()).hexdigest(),buffers=state.bytes());save(result);print(name,j+1,flush=True);del out,state,x;c.reset();torch.cuda.empty_cache()
   losses=[n for i in range(40) for n in v['windows'][str(i)]['token_nll']];v.update(status='completed',scored_tokens=len(losses),ppl=math.exp(sum(losses)/len(losses)),mean_nll=sum(losses)/len(losses));save(result)
  delta=max(abs(a-b) for i in range(40) for a,b in zip(result['results']['td_state_fake']['windows'][str(i)]['token_nll'],result['results']['td_state_packed']['windows'][str(i)]['token_nll']));result['fake_packed_max_abs_token_nll']=delta;assert delta<1e-5,delta
  result.update(status='completed');result.pop('current',None);result.pop('error',None);save(result)
 except Exception as e:result.update(status='failed',error=repr(e));save(result);raise
if __name__=='__main__':main()
