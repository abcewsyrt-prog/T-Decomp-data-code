from pathlib import Path
import sys,os,json,time,hashlib,math,gc,random
R=Path('/REDACTED_PATH/tdecomp_nc_20261028');repo=R/'official_baselines/Quamba';sys.path.insert(0,str(repo));os.chdir(repo);os.environ['HF_HUB_OFFLINE']='1';os.environ['TOKENIZERS_PARALLELISM']='false'
import torch,torch.nn.functional as F
from safetensors.torch import load_file
from transformers import AutoTokenizer
from mamba_ssm.models.config_mamba import MambaConfig
from mamba_ssm.models.mixer_seq_simple import MambaLMHeadModel
from quamba.modelutils_mamba import quantize_model_mamba
from utils import parse_options
OUT=R/'official_baselines/quamba_w4a16_quality.json'
def save():p=OUT.with_suffix('.tmp');p.write_text(json.dumps(result,indent=2,allow_nan=False));p.replace(OUT)
def load_model():
 sd=load_file('/REDACTED_PATH/model.safetensors',device='cpu');sd['backbone.embedding.weight']=sd.pop('backbone.embeddings.weight');sd['lm_head.weight']=sd['backbone.embedding.weight'];cfg=MambaConfig(d_model=1536,n_layer=48,vocab_size=50280,rms_norm=True,residual_in_fp32=True,fused_add_norm=False,ssm_cfg={'d_state':16,'d_conv':4,'expand':2,'dt_rank':96},tie_embeddings=True);m=MambaLMHeadModel(cfg,device='cpu',dtype=torch.float32).eval();m.load_state_dict(sd,strict=True);del sd;return m.half().cuda()
result=json.loads(OUT.read_text()) if OUT.exists() else dict(status='waiting_identity',results={},scope='official Quamba kernel quality, locally supplied WT2 train calibration; no latency claim',source_commit='c474646a922d176f0c6bca0d54cf0fcda8cf9c65')
try:
 torch.set_num_threads(4);torch.manual_seed(42);torch.backends.cuda.matmul.allow_tf32=False
 for _ in range(120):
  p=R/'official_baselines/mamba_checkpoint_identity.json';identity=json.loads(p.read_text()) if p.exists() else {}
  if identity.get('status') in ['completed','failed']:break
  time.sleep(5)
 assert identity.get('status')=='completed',identity
 assert max(x['relative_l2'] for x in identity['comparisons'])<1e-4 and all(x['argmax_agreement']==1 for x in identity['comparisons']),identity
 tok=AutoTokenizer.from_pretrained('/REDACTED_PATH/gpt-neox-20b-tokenizer',local_files_only=True)
 trainpath=Path('/REDACTED_PATH/wiki.train.tokens');text=trainpath.read_text();train=tok(text,add_special_tokens=False,return_tensors='pt').input_ids;g=random.Random(42);starts=[g.randrange(0,train.shape[1]-512) for _ in range(512)];calib=[train[:,i:i+512].clone() for i in starts]
 test=Path('/REDACTED_PATH/wiki.test.tokens').read_text()[:200000];ids=tok(test,add_special_tokens=False,return_tensors='pt').input_ids[0][4096:]
 result.update(status='running',identity=identity,protocol=dict(calibration='W4A16 has no activation calibration; official weight-only path; train windows prepared but unused',train_sha256=hashlib.sha256(text.encode()).hexdigest(),calibration_starts=starts,test_sha256=hashlib.sha256(test.encode()).hexdigest(),score='40 windows,512 inputtokens,stride256,offset4096,last256 target positions perwindow',dtype='FP16 model reference; real official packed weight/activation kernels',embedding_and_lmhead='default unquantized',group_heads=False));save()
 for name,wbits in [('native_FP16',None),('Quamba_W4A16',4)]:
  if name in result['results']:continue
  result['current']=name;save();m=load_model()
  if wbits:
   sys.argv=['run','mamba-790m','--w_bits',str(wbits),'--a_bits','16','--calib_data_num','512','--calib_seqlen','512'];args=parse_options();t=time.perf_counter();m=quantize_model_mamba(m,'mamba',tok,'cuda',args,calibration_dataset=calib,calib_preprocess_fn=lambda x:x.cuda());calibration_seconds=time.perf_counter()-t
  else:calibration_seconds=0.
  losses=[]
  with torch.inference_mode():
   for wi in range(40):
    seq=ids[wi*256:wi*256+513].cuda();assert len(seq)==513;logits=m(seq[:-1][None]).logits[0,-256:].float();loss=F.cross_entropy(logits,seq[1:][-256:],reduction='none').cpu();losses.append([float(v) if torch.isfinite(v) else None for v in loss]);print(name,wi+1,'nonfinite',int((~torch.isfinite(loss)).sum()),flush=True)
  bad=sum(v is None for x in losses for v in x);total=sum(sum(x) for x in losses) if not bad else None;n=sum(len(x) for x in losses);result['results'][name]=dict(status='finite' if not bad else 'nonfinite_kernel_output',nonfinite_targets=bad,scored_tokens=n,nll_sum=total,ppl=math.exp(total/n) if total is not None else None,window_token_nll=losses,calibration_seconds=calibration_seconds,parameter_and_buffer_bytes=sum(p.numel()*p.element_size() for p in m.parameters())+sum(p.numel()*p.element_size() for p in m.buffers()));save();del m;gc.collect();torch.cuda.empty_cache()
 result['status']='completed';result.pop('current',None);result.pop('error',None);save()
except Exception as e:result.update(status='failed',error=repr(e));save();raise
