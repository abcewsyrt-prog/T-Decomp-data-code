"""Reaggregate released output records; no inference or statistical testing."""
from pathlib import Path
import json,math,statistics,csv,hashlib
R=Path(__file__).resolve().parent
J=lambda p:json.loads((R/p).read_text())
report={};checks=[]
def check(condition,msg):
 if not condition:raise AssertionError(msg)
 checks.append(msg)
tasks=J('02_tasks/full_tasks.json')['results'];check(len(tasks)==20,'20 task/configuration groups')
for key,v in tasks.items():
 items=J('02_tasks/'+Path(v['records']).name)
 check(len(items)==v['n'],key+' item count')
 for metric,flag in [('correct','correct'),('correct_norm','correct_norm')]:
  if metric in v:
   check(sum(bool(x[flag]) for x in items)==v[metric],key+' '+metric+' recount')
report['task_groups']=len(tasks);report['task_evaluations']=sum(v['n'] for v in tasks.values())
ret=J('03_retrieval/full_retrieval.json')['results'];check(len(ret)==100,'100 retrieval cells')
for k,v in ret.items():
 check(v['complete'] and v['n']==100 and len(v['records'])==100,k+' complete records')
 check(sum(bool(x['exact_match']) for x in v['records'])==v['successes'],k+' successes recount')
report['retrieval_cells']=len(ret);report['retrieval_evaluations']=sum(v['n'] for v in ret.values())
p=J('07_packed_quality/packed_full_quality.json')['results'];report['packed_quality']={}
for k,v in p.items():
 losses=[n for w in v['windows'].values() for n in w['token_nll']]
 check(len(losses)==10240==v['scored_tokens'],k+' packed-quality scored tokens')
 ppl=math.exp(sum(losses)/len(losses));check(abs(ppl-v['ppl'])<1e-7,k+' packed-quality PPL')
 report['packed_quality'][k]={'scored_tokens':len(losses),'recomputed_ppl':ppl}
a=p['td_state_fake']['windows'];b=p['td_state_packed']['windows']
check(all(a[k]['input_sha256']==b[k]['input_sha256'] and a[k]['token_nll']==b[k]['token_nll'] for k in a),'packed and numerical-state token losses identical on paired inputs')
t=J('08_packed_timing/packed_probe.json')['latency'];report['timing']={}
for k,v in t.items():
 samples=v['decode_samples_seconds'];check(len(samples)==100,k+' 100 measured decode samples')
 median=statistics.median(samples)*1000
 check(abs(median-v['decode_ms_median'])<1e-7,k+' median milliseconds recount')
 report['timing'][k]={'n':len(samples),'median_ms':median}
report['passed']=True;report['checks_passed']=len(checks)
(R/'validation_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in {'packed_quality','timing'}},indent=2))
