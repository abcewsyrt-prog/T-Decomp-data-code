"""Actual 6/8-bit state storage prototype, separate from update-only quantization."""
import torch
from core_controller import Ctrl
# The numerical harness rounds residuals to FP16 then promotes them for arithmetic.
# This prototype retains the physical residual buffer as FP16.
class DeploymentCtrl(Ctrl):
 def reset(self):super().reset();self.last_bits={}
 def step(self,lid,S,w,ab,vk,B,H,N,L,v=None,k=None):
  if self.method=='none':return super().step(lid,S,w,ab,vk,B,H,N,L,v,k)
  threshold=self.threshold.get(lid,torch.full((B,1,1,1),.85,device=w.device))
  mask=w>=threshold;energy=(w*(~mask)).square().sum((1,2,3),keepdim=True).sqrt();prior=self.energy.get(lid,energy)
  bits=torch.where(mask,8,torch.where(energy>1.5*prior,8,6))
  self.threshold[lid]=.99*threshold+.01*w.mean((1,2,3),keepdim=True);self.energy[lid]=.99*prior+.01*energy
  u=vk.float();qm=2.**(bits.float()-1)-1;scale=u.abs().amax(-1,keepdim=True).clamp_min(1e-12)/qm;q=(u/scale).round().clamp(-qm,qm)*scale
  old=self.res.get(lid,torch.zeros_like(u));correction=w*old*mask
  self.res[lid]=((u-q)*(~mask)).half();self.last_bits[lid]=bits
  out=S.float()*w+S.float()@ab.float()+q+correction;return out,out

def pack_mask(mask):
 flat=mask.reshape(-1).to(torch.int32);pad=(-flat.numel())%8
 if pad:flat=torch.cat((flat,torch.zeros(pad,device=flat.device,dtype=flat.dtype)))
 return (flat.reshape(-1,8)<<torch.arange(8,device=flat.device)).sum(-1).to(torch.uint8)
def unpack_mask(packed,count):
 return ((packed.to(torch.int32)[:,None]>>torch.arange(8,device=packed.device))&1).reshape(-1)[:count].bool()
class EncodedState:
 def __init__(self,S,bits):
  B,H,N,_=S.shape;self.shape=S.shape;keymask=bits.eq(8);fullmask=keymask.expand_as(S)
  self.scale=S.abs().amax(-1,keepdim=True).clamp_min(1e-12).float();qm=torch.where(fullmask,127.,31.)
  integers=(S/self.scale*qm).round().clamp(-qm,qm).to(torch.int32)
  self.high=(integers[fullmask]+127).to(torch.uint8);low=(integers[~fullmask]+31).to(torch.int32);self.low_count=low.numel()
  pad=(-low.numel())%4
  if pad:low=torch.cat((low,torch.zeros(pad,device=S.device,dtype=low.dtype)))
  z=low.reshape(-1,4);word=z[:,0]|(z[:,1]<<6)|(z[:,2]<<12)|(z[:,3]<<18)
  self.low=torch.stack((word&255,(word>>8)&255,(word>>16)&255),dim=-1).to(torch.uint8).reshape(-1)
  self.mask=pack_mask(keymask)
 def decode(self):
  B,H,N,_=self.shape;mask=unpack_mask(self.mask,B*H*N).reshape(B,H,1,N).expand(self.shape)
  z=self.low.reshape(-1,3).to(torch.int32);word=z[:,0]|(z[:,1]<<8)|(z[:,2]<<16)
  low=torch.stack((word&63,(word>>6)&63,(word>>12)&63,(word>>18)&63),-1).reshape(-1)[:self.low_count]-31
  out=torch.empty(self.shape,device=self.high.device,dtype=torch.float32);out[mask]=(self.high.to(torch.int32)-127).float()/127;out[~mask]=low.float()/31
  return out*self.scale
 def tensors(self):return [self.high,self.low,self.mask,self.scale]
class ModelState:
 def __init__(self,mode,ctrl):self.mode=mode;self.ctrl=ctrl;self.layers={}
 def read(self,lid):
  if lid not in self.layers:return None,None,None
  a,f,s=self.layers[lid];return a,f,s.decode() if isinstance(s,EncodedState) else s
 def write(self,lid,a,f,s):
  if self.mode in ('state_fake','state_packed'):
   bits=self.ctrl.last_bits.pop(lid);encoded=EncodedState(s,bits);s=encoded.decode() if self.mode=='state_fake' else encoded
  elif self.mode=='fp16_state':s=s.half()
  else:self.ctrl.last_bits.pop(lid,None)
  self.layers[lid]=(a.clone(),f.clone(),s)
 def bytes(self):
  seen=set();total=0;components={'state':0,'shift':0,'residual':0,'EMA':0}
  def add(t,key):
   nonlocal total
   storage=t.untyped_storage();ident=(str(t.device),storage.data_ptr())
   if ident not in seen:seen.add(ident);n=storage.nbytes();components[key]+=n;total+=n
  for a,f,s in self.layers.values():
   add(a,'shift');add(f,'shift')
   for t in s.tensors() if isinstance(s,EncodedState) else [s]:add(t,'state')
  for t in self.ctrl.res.values():add(t,'residual')
  for dic in [self.ctrl.threshold,self.ctrl.energy,self.ctrl.last_bits]:
   for t in dic.values():add(t,'EMA')
  return {'total_bytes':total,'components':components}
