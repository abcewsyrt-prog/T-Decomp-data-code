import os,sys,json,time,math,hashlib,re
from pathlib import Path
os.environ['HF_HUB_OFFLINE']='1';os.environ['TOKENIZERS_PARALLELISM']='false'
sys.path[:0]=['/REDACTED_ROOT','/REDACTED_PATH/tsq']
import torch,torch.nn.functional as F
import pyarrow as pa,pyarrow.ipc as ipc
from tsq.common import load_rwkv7
from tsq.rwkv7_rec import install
from core_controller import Ctrl
ROOT=Path('/REDACTED_PATH/tdecomp_nc_20261028');OUT=ROOT/'full_tasks.json'
def save(o):
 p=OUT.with_suffix('.tmp');p.write_text(json.dumps(o,indent=2,allow_nan=False));p.replace(OUT)
def loadrows(name,split):
 p=Path('/REDACTED_PATH/lm_tasks')/name/split/'data-00000-of-00001.arrow'
 return ipc.open_stream(pa.memory_map(str(p))).read_all().to_pylist(),hashlib.sha256(p.read_bytes()).hexdigest()
def examples():
 out={};hashes={}
 for name,repo,split in [('arc_challenge','ai2_arc_ARC-Challenge','test'),('piqa','piqa','validation'),('arc_easy','ai2_arc_ARC-Easy','test'),('hellaswag','hellaswag','validation')]:
  rows,sha=loadrows(repo,split);items=[]
  for i,r in enumerate(rows):
   if name.startswith('arc'):
    ch=r['choices'];texts=ch['text'];gold=ch['label'].index(r['answerKey']);ctx='Question: '+r['question']+'\nAnswer:'
   elif name=='piqa':ctx='Question: '+r['goal']+'\nAnswer:';texts=[r['sol1'],r['sol2']];gold=int(r['label'])
   else:
    def clean(s):return re.sub(r'\[.*?\]','',s.replace(' [title] ','. ')).strip().replace('  ',' ')
    ctx=clean(r['activity_label']+': '+r['ctx_a']+' '+r['ctx_b'].capitalize());texts=[clean(s) for s in r['endings']];gold=int(r['label'])
   assert 0<=gold<len(texts);items.append(dict(id=i,context=ctx,choices=texts,gold=gold))
  out[name]=items;hashes[name]=dict(source=repo,split=split,sha256=sha,n=len(items))
 p=Path('/REDACTED_PATH/lambada_test.jsonl');items=[]
 for i,line in enumerate(p.open()):
  text=json.loads(line)['text'];ctx,word=text.rsplit(' ',1);items.append(dict(id=i,context=ctx,choices=[word],gold=0))
 out['lambada']=items;hashes['lambada']=dict(source='RWKV-LM official misc/lambada_test.jsonl',split='test',sha256=hashlib.sha256(p.read_bytes()).hexdigest(),n=len(items))
 return out,hashes

def main():
 torch.set_num_threads(4);torch.set_num_interop_threads(2);torch.manual_seed(42);torch.backends.cuda.matmul.allow_tf32=False
 data,hashes=examples();res=json.loads(OUT.read_text()) if OUT.exists() else dict(results={},protocol=dict(model='/REDACTED_PATH/rwkv7_2b9',dtype='FP32',full_splits=True,data=hashes,scoring='zero-shot conditional completion log likelihood; raw acc and token-length-normalized acc; LAMBADA all target tokens greedy exact under teacher-forced context, standard cloze metric, not free generation',quantizer='fixed native value row scale',controller='core_controller.py; masked EMA 8/6; reset per candidate; no truncation; full split no subsampling'))
 res['status']='loading';save(res);model,tok=load_rwkv7('/REDACTED_PATH/rwkv7_2b9',dtype=torch.float32);c=Ctrl();install(model,c);res['status']='running';save(res)
 specs=[('reference','none',8),('uniform_int8','uniform8',8),('uniform_int4','uniform4',4),('td_masked_ema_8_6','balanced',8)]
 for task in ['arc_challenge','piqa','arc_easy','lambada','hellaswag']:
  # Tokenize independently per question/choice, preserving complete inputs.
  pairs=[]
  for ex in data[task]:
   ctx=ex['context'];ctx=ctx.rstrip();prefix=tok(ctx,add_special_tokens=False)['input_ids']
   assert len(prefix)>0
   for j,choice in enumerate(ex['choices']):
    tail=tok(' '+choice,add_special_tokens=False)['input_ids'];assert len(tail)>0
    pairs.append(dict(item=ex['id'],choice=j,ids=prefix+tail,start=len(prefix),target=tail))
  pairs.sort(key=lambda x:len(x['ids']))
  print('task_ready',task,len(data[task]),len(pairs),flush=True)
  for config,method,bits in specs:
   key=task+'/'+config
   if key in res['results']:continue
   c.method=method;c.bits=bits;scores={};nll=0.;count=0;starttime=time.time();begin=0
   progress=ROOT/('task_progress_'+task+'_'+config+'.json')
   while begin<len(pairs):
    batch=[];maxlen=0
    while begin+len(batch)<len(pairs) and len(batch)<32:
     p=pairs[begin+len(batch)];newmax=max(maxlen,len(p['ids']))
     if batch and newmax*(len(batch)+1)>8192:break
     batch.append(p);maxlen=newmax
    x=torch.zeros((len(batch),maxlen),dtype=torch.long,device='cuda')
    rr=[];pos=[];targets=[];offset=[0]
    for k,p in enumerate(batch):
     x[k,:len(p['ids'])]=torch.tensor(p['ids'],device='cuda');n=len(p['target']);rr.extend([k]*n);pos.extend(range(p['start']-1,len(p['ids'])-1));targets+=p['target'];offset.append(len(targets))
    c.reset();c.schedules.clear()
    with torch.inference_mode():
     h=model.rwkv7(input_ids=x,use_cache=False).last_hidden_state
     selected=h[torch.tensor(rr,device='cuda'),torch.tensor(pos,device='cuda')];logits=model.head(selected).float()
     losses=F.cross_entropy(logits,torch.tensor(targets,device='cuda'),reduction='none').cpu();pred=logits.argmax(-1).cpu().tolist()
    for k,p in enumerate(batch):
     lo,hi=offset[k:k+2];loss=float(losses[lo:hi].double().sum());good=pred[lo:hi]==p['target']
     scores.setdefault(p['item'],{})[p['choice']]=dict(nll=loss,tokens=hi-lo,greedy_all_tokens=good)
     nll+=loss;count+=hi-lo
    begin+=len(batch);del h,selected,logits,losses,x
    if begin%256<len(batch) or begin==len(pairs):
     progress.write_text(json.dumps(dict(task=task,configuration=config,candidates_done=begin,candidates_total=len(pairs),elapsed_seconds=time.time()-starttime)))
     print('progress',task,config,begin,'/',len(pairs),flush=True)
   correct=[];norm=[];records=[]
   for ex in data[task]:
    ss=scores[ex['id']]
    if task=='lambada':good=ss[0]['greedy_all_tokens'];goodnorm=good
    else:good=min(ss,key=lambda j:ss[j]['nll'])==ex['gold'];goodnorm=min(ss,key=lambda j:ss[j]['nll']/ss[j]['tokens'])==ex['gold']
    correct.append(int(good));norm.append(int(goodnorm));records.append(dict(id=ex['id'],gold=ex['gold'],correct=good,correct_norm=goodnorm,choices=ss))
   assert len(records)==len(data[task]);recfile=ROOT/('task_items_'+task+'_'+config+'.json');recfile.write_text(json.dumps(records))
   res['results'][key]=dict(n=len(records),correct=sum(correct),accuracy=sum(correct)/len(correct),correct_norm=sum(norm),accuracy_norm=sum(norm)/len(norm),target_tokens=count,completion_nll=nll,elapsed_seconds=time.time()-starttime,records=recfile.name)
   save(res);print('COMPLETED',key,res['results'][key],flush=True)
 res['status']='completed';save(res)
if __name__=='__main__':main()
