import os,sys,json,time,statistics,math
from pathlib import Path
os.environ['HF_HUB_OFFLINE']='1';sys.path[:0]=['/REDACTED_ROOT','/REDACTED_PATH/tsq']
import torch,torch.nn.functional as F
from tsq.common import load_rwkv7
from tsq.rwkv7_rec import install
from packed_state_backend import DeploymentCtrl,ModelState,EncodedState
R=Path('/REDACTED_PATH/tdecomp_nc_20261028');OUT=R/'packed_probe.json'
def save(o):p=OUT.with_suffix('.tmp');p.write_text(json.dumps(o,indent=2,allow_nan=False));p.replace(OUT)
def main():
 if OUT.exists() and json.loads(OUT.read_text()).get('status')=='completed':
  print('Completed packed probe retained',flush=True);return
 import fcntl
 # Wait for any full packed-quality process before allocating timing resources.
 quality_lock=open(str(R/'packed_full_quality.json')+'.lock','a');fcntl.flock(quality_lock,fcntl.LOCK_EX)
 torch.set_num_threads(4);torch.set_num_interop_threads(2);torch.manual_seed(42);torch.backends.cuda.matmul.allow_tf32=False
 # Check both physical codecs before allocating model weights.
 for shape in [(2,3,8,8),(1,40,64,64)]:
  x=torch.randn(shape,device='cuda');b=torch.where(torch.rand(shape[0],shape[1],1,shape[2],device='cuda')>.5,8,6);e=EncodedState(x,b);qm=2.**(b-1)-1;s=x.abs().amax(-1,keepdim=True).clamp_min(1e-12);q=(x/s*qm).round().clamp(-qm,qm)/qm*s
  assert torch.equal(e.decode(),q)
 model,tok=load_rwkv7('/REDACTED_PATH/rwkv7_2b9',dtype=torch.float32);c=DeploymentCtrl();install(model,c);ids=torch.load('/REDACTED_PATH/wiki.test.ids.pt')[4096:].cuda()
 c.method='none';c.reset()
 with torch.inference_mode():
  native=model(ids[:64][None],use_cache=True,logits_to_keep=1);native2=model(ids[64:65][None],state=native.state,use_cache=True,logits_to_keep=1)
 c.reset();checkstate=ModelState('reference',c)
 with torch.inference_mode():
  custom=model(ids[:64][None],state=checkstate,use_cache=True,logits_to_keep=1);custom2=model(ids[64:65][None],state=checkstate,use_cache=True,logits_to_keep=1)
 identity={'prefill_max_abs_logits':float((native.logits-custom.logits).abs().max()),'decode_max_abs_logits':float((native2.logits-custom2.logits).abs().max())}
 assert max(identity.values())<1e-3,identity
 del native,native2,custom,custom2,checkstate;torch.cuda.empty_cache()
 result=dict(status='running',native_cache_identity=identity,codec_checks='passed exact reconstruction against numerical 6/8 quantizer',protocol=dict(scope='physical packed-state prototype; additional recurrent write-back intervention, distinct from update-only main results',model_dtype='FP32 weights/activations',residual='physical FP16 buffer',quality='8 windows, prefix64, score64 teacher-forced one-token cached steps; 512 target tokens per configuration',latency='eager complete-model cached decode; warmup20 + measurements100, one token each, batch1/16/64/128; no diagnostic histogram counters; packing overhead included',DRAM='not measured; no profiler counters installed'),quality={},latency={});save(result)
 specs=[('reference','none','reference'),('td_update_only','balanced','reference'),('td_state_fake','balanced','state_fake'),('td_state_packed','balanced','state_packed')];saved={}
 for name,method,mode in specs:
  c.method=method;allloss=[]
  for j in range(8):
   c.reset();state=ModelState(mode,c);x=ids[j*128:j*128+129][None]
   with torch.inference_mode():
    out=model(x[:,:64],state=state,use_cache=True,logits_to_keep=1);losses=[]
    for t in range(64,128):
     losses.append(float(F.cross_entropy(out.logits[:,-1].float(),x[:,t])));out=model(x[:,t:t+1],state=state,use_cache=True,logits_to_keep=1)
   allloss.extend(losses)
  mean=sum(allloss)/len(allloss);saved[name]=allloss;result['quality'][name]=dict(scored_tokens=len(allloss),mean_nll=mean,ppl=math.exp(mean),state_buffers=state.bytes());save(result);print('quality',name,mean,flush=True);del state,out,x;c.reset();torch.cuda.empty_cache()
 assert max(abs(a-b) for a,b in zip(saved['td_state_fake'],saved['td_state_packed']))<1e-5
 result['fake_packed_max_abs_token_nll']=max(abs(a-b) for a,b in zip(saved['td_state_fake'],saved['td_state_packed']));(R/'packed_quality_token_losses.json').write_text(json.dumps(saved));save(result)
 for B in [1,16,64,128]:
  for name,method,mode in specs:
   c.method=method;c.reset();torch.cuda.empty_cache();state=ModelState(mode,c)
   out=None;next_id=None;prompt=None
   try:
    prompt=ids[:32][None].expand(B,-1).contiguous();torch.cuda.reset_peak_memory_stats()
    with torch.inference_mode():
     torch.cuda.synchronize();prefill_start=time.perf_counter();out=model(prompt,state=state,use_cache=True,logits_to_keep=1);torch.cuda.synchronize();prefill_ms=1000*(time.perf_counter()-prefill_start);next_id=out.logits[:,-1].argmax(-1)[:,None];times=[]
     for i in range(120):
      torch.cuda.synchronize();start=time.perf_counter();out=model(next_id,state=state,use_cache=True,logits_to_keep=1);next_id=out.logits[:,-1].argmax(-1)[:,None];torch.cuda.synchronize();dt=time.perf_counter()-start
      if i>=20:times.append(dt)
    result['latency'][f'{B}/{name}']=dict(batch=B,measurements=len(times),prefill_single_ms=prefill_ms,decode_samples_seconds=times,decode_ms_median=1000*statistics.median(times),decode_ms_mean=1000*statistics.mean(times),tokens_s=B/statistics.mean(times),peak_allocated_bytes=torch.cuda.max_memory_allocated(),allocated_bytes=torch.cuda.memory_allocated(),buffers=state.bytes());save(result);print('latency',B,name,flush=True)
   except torch.cuda.OutOfMemoryError:result['latency'][f'{B}/{name}']=dict(batch=B,status='OOM');save(result)
   del state,out,next_id,prompt;c.reset();torch.cuda.empty_cache()
 result['status']='completed';save(result)
if __name__=='__main__':main()
