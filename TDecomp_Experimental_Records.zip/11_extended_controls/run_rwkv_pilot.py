import os,sys,json,time,math,hashlib,traceback
os.environ['HF_HUB_OFFLINE']='1';os.environ['HF_DATASETS_OFFLINE']='1';os.environ['TOKENIZERS_PARALLELISM']='false'
sys.path[:0]=['/REDACTED_ROOT','/REDACTED_PATH/tsq']
import torch
import torch.nn.functional as F
from tsq.common import load_rwkv7
from tsq.rwkv7_rec import install
ROOT='/REDACTED_PATH/tdecomp_nc_20261028';os.makedirs(ROOT,exist_ok=True)
OUT=ROOT+'/rwkv_pilot.json'
def save(obj):
    with open(OUT+'.tmp','w') as f:json.dump(obj,f,indent=2,allow_nan=False)
    os.replace(OUT+'.tmp',OUT)
class Ctrl:
    def __init__(self):self.method='none';self.bits=8;self.n_layer=1;self._lid=0;self.reset()
    def reset(self):self.res={};self.frozen={};self.steps={};self.hist={};self.decay={}
    def _ensure(self,*a):pass
    def step(self,lid,S,w,ab,vk,B,H,N,L,v=None,k=None):
        w=w.float();ab=ab.float();vk=vk.float();s=S.float();base=s*w+s@ab
        if self.method=='none':return base+vk,base+vk
        feedback=self.method in ('temporal_feedback','temporal_native_feedback')
        r=self.res.get(lid,torch.zeros_like(vk))
        correction=r*w if feedback else 0
        if self.method=='temporal_native_feedback':correction=r*w+r@ab
        u=vk+correction
        step=self.steps.get(lid,0);self.steps[lid]=step+1
        if self.method.startswith('uniform'):
            bits=torch.full((B,H),self.bits,device=s.device,dtype=torch.int64);kh=H if self.bits==8 else 0
        else:
            kh=round(H*.8);decay=w.mean(dim=(-1,-2))
            if self.method=='random':
                g=torch.Generator(device=s.device);g.manual_seed(42+lid*100000+step);score=torch.rand((B,H),device=s.device,generator=g)
            elif self.method=='magnitude':score=vk.square().sum((-1,-2))
            elif self.method=='inverted':score=-decay
            else:score=decay
            ix=torch.argsort(score,dim=-1,descending=True,stable=True)[:,:kh]
            mask=torch.zeros((B,H),dtype=torch.bool,device=s.device);mask.scatter_(1,ix,True)
            if self.method=='frozen':mask=self.frozen.setdefault(lid,mask.clone())
            bits=torch.where(mask,8,6)
            if step==0:self.decay[lid]=dict(head_mean=decay.detach().cpu().tolist(),assignment_bits=bits.detach().cpu().tolist())
        qm=(2.**(bits.float()-1)-1)[...,None,None]
        # Same per-sample tensor absmax for every routed method; differing bits only alter resolution.
        scale=u.abs().amax((1,2,3),keepdim=True).clamp_min(1e-12)/qm
        q=torch.round(u/scale).clamp(-qm,qm)*scale
        if feedback:self.res[lid]=(u-q).half().float()
        hist=self.hist.setdefault(lid,dict(elements=0,bit_elements={}))
        hist['elements']+=B*H*N*N
        if self.method.startswith('uniform'):entries={self.bits:B*H*N*N}
        else:entries={8:B*kh*N*N,6:B*(H-kh)*N*N}
        for b,count in entries.items():hist['bit_elements'][str(b)]=hist['bit_elements'].get(str(b),0)+count
        out=base+q;return out,out

def main():
    torch.set_num_threads(4);torch.set_num_interop_threads(2);torch.manual_seed(42);torch.backends.cuda.matmul.allow_tf32=False
    res=dict(status='loading',scope='loaded_RWKV7_2.9B_small_WikiText2_test_pilot',not_full_benchmark=True,intervention='rank1_increment_vk_only; native S@ab term preserved',dtype='float32',gpu=torch.cuda.get_device_name(),torch=torch.__version__,started=time.time(),results={})
    save(res);model,tok=load_rwkv7('/REDACTED_PATH/rwkv7_2b9',dtype=torch.float32)
    print('model_loaded',flush=True)
    model.config.wkv_implementation='chunked'
    for m in model.modules():
        if hasattr(m,'config') and hasattr(m,'lora_gates'):m.config.wkv_implementation='chunked'
    text=open('/REDACTED_PATH/wiki.test.tokens').read()[:12000];ids=tok(text,add_special_tokens=False,return_tensors='pt').input_ids[0]
    print('tokenized',len(ids),flush=True)
    res.update(parameters=sum(p.numel() for p in model.parameters()),tokenizer_vocab=tok.vocab_size,corpus_tokens=len(ids),data_sha256=hashlib.sha256(text.encode()).hexdigest(),shape=dict(layers=model.config.num_hidden_layers,heads=model.config.num_heads,head_dim=model.config.head_dim))
    identity=ids[:32][None].cuda()
    with torch.inference_mode():native=model(identity,use_cache=False).logits.float().cpu()
    ctrl=Ctrl();install(model,ctrl)
    with torch.inference_mode():patched=model(identity,use_cache=False).logits.float().cpu()
    err=(native-patched).abs();res['identity']=dict(max_abs_logits=float(err.max()),mean_abs_logits=float(err.mean()),argmax_agreement=float((native.argmax(-1)==patched.argmax(-1)).float().mean()),native_mode='original chunked registry',patched_mode='native recurrence, no quantization')
    if float(err.max())>1e-3:res['status']='identity_failed';save(res);return
    del native,patched;torch.cuda.empty_cache();res['status']='running';save(res)
    length=128;stride=64;nw=4
    xs=torch.stack([ids[i*stride:i*stride+length] for i in range(nw)]).cuda()
    targets=xs[:,1:];res['protocol']=dict(split='test',length=length,stride=stride,windows=nw,score='last 64 target positions in each window; unique positions',scored_tokens=nw*stride,seed=42,calibration=None,input_sha256=hashlib.sha256(xs.cpu().numpy().tobytes()).hexdigest())
    specs=[('reference','none',8),('uniform8','uniform8',8),('uniform6','uniform6',6),('uniform4','uniform4',4),('temporal_7p6','temporal',8),('random_7p6','random',8),('inverted_7p6','inverted',8),('magnitude_7p6','magnitude',8),('frozen_7p6','frozen',8),('temporal_decay_feedback','temporal_feedback',8),('temporal_native_transition_feedback','temporal_native_feedback',8)]
    for name,method,bits in specs:
        ctrl.method=method;ctrl.bits=bits;ctrl.reset();torch.cuda.synchronize();t0=time.perf_counter()
        with torch.inference_mode():
            logits=model(xs,use_cache=False).logits[:,:-1].float();loss=F.cross_entropy(logits.reshape(-1,logits.size(-1)),targets.reshape(-1),reduction='none').reshape(nw,length-1)
            scored=loss[:,-stride:];means=scored.mean(1).cpu().tolist();total=float(scored.sum());count=scored.numel()
        torch.cuda.synchronize();seconds=time.perf_counter()-t0;mean=total/count
        row=dict(nll_sum=total,scored_tokens=count,mean_nll=mean,ppl=math.exp(mean) if mean<709 else None,window_mean_nll=means,elapsed_seconds=seconds,allocation_histograms=ctrl.hist,decay_first_step=ctrl.decay,feedback=method if 'feedback' in method else 'off',scope='small_test_slice; no energy promotion; 8/6 head quota family; no packed-state claim')
        res['results'][name]=row
        with open(ROOT+'/'+name+'_token_nll.json','w') as f:json.dump(scored.cpu().tolist(),f)
        save(res);print(name,json.dumps({k:row[k] for k in ['ppl','mean_nll','scored_tokens','elapsed_seconds']}),flush=True)
        del logits,loss,scored;torch.cuda.empty_cache()
    res['status']='completed';res['finished']=time.time();save(res)
if __name__=='__main__':
    try:main()
    except Exception:
        with open(ROOT+'/error.txt','w') as f:f.write(traceback.format_exc())
        raise
