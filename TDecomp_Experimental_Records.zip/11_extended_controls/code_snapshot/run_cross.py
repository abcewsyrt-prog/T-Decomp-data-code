#!/usr/bin/env python3
"""Cross-architecture sweep: Transformer KV cache vs Mamba recurrent state.

usage: run_cross.py <tag> <out.json> [--windows 20] [--seq 512] [--stride 256]

tags: llama1b | qwen3b | falcon3b | mamba790

For Transformers this quantizes the *KV cache* (K after RoPE, V at v_proj).
For Mamba it quantizes the *recurrent SSM state* h_t [B, D, N] inside the
sequential scan, by source-patching `MambaMixer.slow_forward` so the rest of
the block is bit-for-bit the original implementation.
"""
import argparse
import inspect
import json
import os
import sys

import torch
import torch.nn.functional as F

sys.path.insert(0, "/root")
sys.path.insert(0, "/REDACTED_PATH/tsq")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tsq.transformer_kv import (KVQuantizer, install, uninstall,   # noqa: E402
                                capture_kv, tensor_stats, sqnr_table)
from tsq.quant import KV_GRAN, fake_quant                          # noqa: E402

MODELS = {
    "llama1b": "/REDACTED_PATH/llama1b",
    "qwen3b": "/REDACTED_PATH/qwen3b",
    "falcon3b": "/REDACTED_PATH/falcon3b",
    "mamba790": "/REDACTED_PATH/mamba790",
}

# SSM state layout [B, D, N]: D = d_inner channels, N = ssm_state_size.
# Decay is ELEMENTWISE in the (D, N) basis, so that basis diagonalises it.
SSM_GRAN = {
    "per_tensor":  dict(rd=(0, 1, 2), g=None),   # 1
    "per_channel": dict(rd=(0, 2),    g=None),   # D      (wrong axis)
    "per_state":   dict(rd=(0, 1),    g=None),   # N      (decay axis)
    "per_element": dict(rd=(0,),      g=None),   # D*N    (decay-aligned)
    "group8":      dict(rd=(0,),      g=8),      # D*N/8
    "group4":      dict(rd=(0,),      g=4),      # D*N/4
}

WIKI = os.environ.get(
    "WIKI_TEST", "/REDACTED_PATH/wiki.test.tokens")


# --------------------------------------------------------------------------- #
#  Mamba: patch the sequential scan                                            #
# --------------------------------------------------------------------------- #
class SSMController:
    """Quantizes the Mamba recurrent state inside the scan loop."""

    def __init__(self):
        self.bits = 16
        self.gran = "per_tensor"
        self.mode = "accum"       # accum = quantize h inside the loop
        self.nscan = 0

    def __call__(self, h):
        if self.bits is None or self.bits >= 16:
            return h
        if self.mode == "inject":
            return h
        c = SSM_GRAN[self.gran]
        return fake_quant(h.float(), self.bits, c["rd"], c["g"]).to(h.dtype)


def install_mamba(model, ctrl):
    """Source-patch MambaMixer.slow_forward to quantize ssm_state."""
    from transformers.models.mamba import modeling_mamba as MM

    src = inspect.getsource(MM.MambaMixer.slow_forward)
    lines = src.split("\n")
    out, hit = [], 0
    for ln in lines:
        out.append(ln)
        st = ln.strip()
        if (st.startswith("ssm_state") and "deltaB_u" in ln
                and "discrete_A" in ln and "*" in ln):
            ind = len(ln) - len(ln.lstrip())
            out.append(" " * ind + "ssm_state = _SSM_CTRL(ssm_state)")
            hit += 1
    if hit != 1:
        raise RuntimeError(f"could not patch Mamba scan (matched {hit} lines)")
    new_src = "\n".join(out)

    ns = dict(vars(MM))
    ns["_SSM_CTRL"] = ctrl
    ns["torch"] = torch
    ns["nn"] = torch.nn
    exec("class _Patched:\n" + new_src, ns)     # noqa: S102
    MM.MambaMixer.slow_forward = ns["_Patched"].slow_forward
    return hit


# --------------------------------------------------------------------------- #
@torch.no_grad()
def eval_ppl(model, ids, seq_len, stride, n_windows, batch, device="cuda"):
    from tsq.common import build_windows
    xs, ys = build_windows(ids, seq_len, stride, n_windows)
    nll, cnt = 0.0, 0
    for s in range(0, xs.size(0), batch):
        x = xs[s:s + batch].to(device)
        y = ys[s:s + batch].to(device)
        logits = model(x, use_cache=False).logits.float()
        nll += F.cross_entropy(logits.reshape(-1, logits.size(-1)),
                               y.reshape(-1), reduction="sum").item()
        cnt += y.numel()
    return float(torch.exp(torch.tensor(nll / cnt)).item())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tag")
    ap.add_argument("out")
    ap.add_argument("--windows", type=int, default=20)
    ap.add_argument("--seq", type=int, default=512)
    ap.add_argument("--stride", type=int, default=256)
    a = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer
    path = MODELS[a.tag]
    is_mamba = a.tag.startswith("mamba")
    dtype = torch.float16
    tok = AutoTokenizer.from_pretrained(path)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        path, dtype=dtype, low_cpu_mem_usage=True).cuda().eval()

    text = open(WIKI, encoding="utf-8").read()
    # tokenize once; truncate generously (we only need the first windows)
    ids = tok(text[:200000], return_tensors="pt").input_ids[0]
    print(f"[{a.tag}] ntok={ids.numel()} windows={a.windows}", flush=True)

    res = dict(model=a.tag, path=path, ntok=int(ids.numel()), runs=[])
    t0 = torch.cuda.Event(True); t1 = torch.cuda.Event(True)
    fp = eval_ppl(model, ids, a.seq, a.stride, a.windows, a.windows)
    res["fp_ppl"] = round(fp, 4)
    print(json.dumps(dict(name="FP", ppl=round(fp, 4))), flush=True)

    ctrl = None
    if is_mamba:
        ctrl = SSMController()
        install_mamba(model, ctrl)
        grans = list(SSM_GRAN.keys())
    else:
        grans = ["per_tensor", "per_token", "per_channel", "per_head",
                 "group32", "group16"]

    for b in (8, 6, 4, 3):
        for g in grans:
            if is_mamba:
                ctrl.bits, ctrl.gran = b, g
            else:
                orig, handles, M = install(
                    model, KVQuantizer(k_bits=b, k_gran=g, v_bits=b, v_gran=g))
            try:
                p = eval_ppl(model, ids, a.seq, a.stride, a.windows, a.windows)
            except Exception as e:
                p = float("nan")
                print(f"  ! {g}/INT{b}: {type(e).__name__}: {e}", flush=True)
            finally:
                if not is_mamba:
                    uninstall(orig, handles, M)
            rec = dict(name=f"{g}/INT{b}", gran=g, bits=b, ppl=p)
            res["runs"].append(rec)
            print(json.dumps(rec), flush=True)

        if not is_mamba:
            # KIVI recipe: K per-channel + V per-token
            orig, handles, M = install(model, KVQuantizer(
                k_bits=b, k_gran="per_channel", v_bits=b, v_gran="per_token"))
            p = eval_ppl(model, ids, a.seq, a.stride, a.windows, a.windows)
            uninstall(orig, handles, M)
            rec = dict(name=f"kivi/INT{b}", gran="kivi", bits=b, ppl=p)
            res["runs"].append(rec)
            print(json.dumps(rec), flush=True)

    if not is_mamba:
        try:
            Ks, Vs = capture_kv(model, tok, text, seq_len=a.seq)
            st = {"K": [tensor_stats(k) for k in Ks],
                  "V": [tensor_stats(v) for v in Vs]}
            agg = lambda key, f: round(          # noqa: E731
                sum(f(s) for s in st[key]) / max(len(st[key]), 1), 4)
            res["rho_K"] = agg("K", lambda s: s["rho"])
            res["rho_V"] = agg("V", lambda s: s["rho"])
            res["kurt_K"] = agg("K", lambda s: s["kurt"])
            res["kurt_V"] = agg("V", lambda s: s["kurt"])
            res["kurt_K_max"] = round(max(s["kurt"] for s in st["K"]), 2)
            res["rho_K_max"] = round(max(s["rho"] for s in st["K"]), 3)
            res["sqnr_K"] = sqnr_table(Ks[len(Ks) // 2], list(KV_GRAN), [8, 6, 4])
            res["sqnr_V"] = sqnr_table(Vs[len(Vs) // 2], list(KV_GRAN), [8, 6, 4])
            print(json.dumps(dict(rho_K=res["rho_K"], rho_V=res["rho_V"],
                                  kurt_K_max=res["kurt_K_max"])), flush=True)
        except Exception as e:
            res["diag_error"] = f"{type(e).__name__}: {e}"
            print("diag failed:", res["diag_error"], flush=True)

    with open(a.out, "w") as f:
        json.dump(res, f, indent=1)
    print("SAVED", a.out, flush=True)


if __name__ == "__main__":
    main()
