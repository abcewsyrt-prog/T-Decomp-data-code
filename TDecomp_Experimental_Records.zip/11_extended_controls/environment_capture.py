import json,platform,sys,hashlib,importlib.metadata,subprocess
from pathlib import Path
p=Path('/REDACTED_PATH/tdecomp_nc_20261028');files=['/REDACTED_PATH/rwkv7_rec.py','/REDACTED_PATH/run_cross.py','/REDACTED_PATH/common.py','/REDACTED_PATH/modeling_rwkv7.py','/REDACTED_PATH/config.json','/REDACTED_PATH/config.json']
r=dict(python=sys.version,platform=platform.platform(),packages={},sha256={})
for n in ['torch','transformers','tokenizers','numpy']:
 try:r['packages'][n]=importlib.metadata.version(n)
 except importlib.metadata.PackageNotFoundError:r['packages'][n]=None
for f in files:
 if Path(f).is_file():r['sha256'][f]=hashlib.sha256(Path(f).read_bytes()).hexdigest()
r['gpu']=subprocess.run(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader'],capture_output=True,text=True).stdout.strip()
(p/'environment.json').write_text(json.dumps(r,indent=2))
