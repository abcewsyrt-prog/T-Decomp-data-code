# Data dictionary and protocol map

| Field / record | Meaning | Unit / interpretation |
|---|---|---|
| `token_nll` | Negative log probability of each scored target token | Natural-log units (nats); PPL = exp(mean NLL) |
| `input_sha256` / `data_sha256` | Digest of the evaluated token input or corpus file | SHA-256; compare within the declared protocol |
| `id` | Question or synthetic trial identifier | Not a person identifier |
| `correct`, `correct_norm` | Raw-likelihood / token-length-normalized decision correctness | Boolean per question; use the paper's chosen metric |
| `choices.*.nll`, `tokens` | Option-completion loss and scored token count | Sum NLL in nats; count of target tokens |
| `exact_match` | Full generated passkey matches target under the recorded stop protocol | Boolean per trial; not substring or first-token matching |
| `n`, `successes`, `exact_match_rate` | Trial count, exact matches, success ratio | Counts and fraction; multiply ratio by 100 for percent |
| `state_relative_frobenius_error` | Relative state discrepancy against matched reference | Dimensionless; native layer/step coordinates |
| `residual_norm` | Recorded residual norm | Native implementation scale; not bytes |
| `actual_update_bits` | Achieved numerical update allocation | Nominal bits/element; excludes auxiliary storage |
| `reference_nll`, `variant_nll`, `excess_nll` | Reference, intervention and paired difference in NLL | Nats; document/token pairing must be retained |
| `decode_samples_seconds` | Successive measured cached decoding-step durations | Seconds per measured step |
| `decode_ms_median` | Median decoding-step duration | Milliseconds; batch size is encoded in configuration key |
| `tokens_s` | Measured aggregate token throughput | Tokens/second under that timing configuration |
| `buffers`, `state_buffers` | Accounted persistent tensor buffers | Bytes; MiB = bytes/2^20 |
| `status`, `scope`, `protocol` | Execution completion and configuration metadata | Completion is scoped to that file, not all possible experiments |

## Link to manuscript evidence
- New native-mechanism and loaded-7.2B tables: `01_core`.
- Five full downstream tasks: `02_tasks` and corresponding summary CSVs.
- Full 1K–16K retrieval table/heatmaps: `03_retrieval`.
- Natural-document, dense-trajectory, matched-seed, Mamba and cross-corpus appendices: `04`–`06`.
- Packed quality and persistent-byte tables: `07`; exclusive model-level timing: `08`.
- Official W4A16 comparison: `09`.
- Earlier RWKV interface controls: `11`; do not merge their baselines with the native-controller protocol.
- Supplied historical model sweeps, Smooth and historical operator results: manuscript table records in `12_source_reported`; corresponding raw logs are not claimed to have been recovered.

The primary experimental units differ: questions for downstream accuracy, paired generated prompts for retrieval, documents for trajectory comparisons, scored targets/windows for language-model loss, and measured decoding steps for timing. Random seeds are repeated controller allocations, not new corpora. No additional statistical independence or significance is asserted.
