import os,sys,json,time,math,hashlib,traceback
os.environ['HF_HUB_OFFLINE']='1';os.environ['HF_DATASETS_OFFLINE']='1';os.environ['TOKENIZERS_PARALLELISM']='false'
sys.path[:0]=['/REDACTED_ROOT','/REDACTED_PATH/tsq']
import torch
import torch.nn.functional as F
from tsq.common import load_rwkv7
from tsq.rwkv7_rec import install
ROOT='/REDACTED_PATH/tdecomp_nc_20261028';os.makedirs(ROOT,exist_ok=True)
OUT=ROOT+'/fixed_quantizer_mechanism.json'
def save(obj):
    with open(OUT+'.tmp','w') as f:json.dump(obj,f,indent=2,allow_nan=False)
    os.replace(OUT+'.tmp',OUT)
class Ctrl:
    def __init__(self):self.method='none';self.bits=8;self.n_layer=1;self._lid=0;self.schedules={};self.batch_index=0;self.reset()
    def reset(self):self.res={};self.steps={};self.hist={};self.decay={};self.threshold={};self.energy={}
    def _ensure(self,*a):pass
    def step(self,lid,S,w,ab,vk,B,H,N,L,v=None,k=None):
        w=w.float();ab=ab.float();vk=vk.float();base=S.float()*w+S.float()@ab
        if self.method=='none':return base+vk,base+vk
        if self.method.startswith('uniform'):
            bits=torch.full_like(w,int(self.bits),dtype=torch.int64);mask=torch.zeros_like(w,dtype=torch.bool)
        else:
            initial=.95 if self.method=='aggressive' else .85
            threshold=self.threshold.get(lid,torch.full((B,1,1,1),initial,device=w.device))
            # Native w is [B,H,1,N]: route key coordinates, broadcast over value rows.
            mask=w>=threshold
            if self.method=='no_routing':mask=torch.zeros_like(mask)
            gate=w*(~mask)
            energy=gate.square().sum((1,2,3),keepdim=True).sqrt()
            prior=self.energy.get(lid,energy)
            promote=energy>1.5*prior
            if self.method=='no_energy':promote=torch.zeros_like(promote)
            # Balanced historical format family: INT8 high/promoted, INT6 base.
            bits=torch.where(mask,8,torch.where(promote,8,6))
            step=self.steps.get(lid,0)
            if self.method=='balanced':self.schedules[(self.batch_index,lid,step)]=(mask.reshape(B,-1).sum(-1,keepdim=True).clone(),promote.clone())
            if self.method in ('random','inverted'):
                flat=mask.reshape(B,-1)
                count,promote=self.schedules[(self.batch_index,lid,step)]
                if self.method=='random':
                    g=torch.Generator(device=w.device);g.manual_seed(42+lid*100000+self.steps.get(lid,0))
                    score=torch.rand(flat.shape,device=w.device,generator=g)
                else:score=-w.reshape(B,-1)
                order=score.argsort(dim=-1,descending=True,stable=True)
                rank=torch.empty_like(order);rank.scatter_(1,order,torch.arange(order.shape[1],device=w.device).expand_as(order))
                mask=(rank<count).reshape_as(mask)
                bits=torch.where(mask,8,torch.where(promote,8,6))
            self.steps[lid]=self.steps.get(lid,0)+1
            self.threshold[lid]=.99*threshold+.01*w.mean((1,2,3),keepdim=True)
            self.energy[lid]=.99*prior+.01*energy
        r=self.res.get(lid,torch.zeros_like(vk))
        if self.method=='all_feedback':operand=vk+w*r;correction=0
        else:operand=vk;correction=w*r*mask if self.method not in ('no_feedback','none') and not self.method.startswith('uniform') else 0
        qm=2.**(bits.float()-1)-1
        scale=operand.abs().amax(-1,keepdim=True).clamp_min(1e-12)/qm
        q=torch.round(operand/scale).clamp(-qm,qm)*scale
        if self.method=='all_feedback':self.res[lid]=(operand-q).half().float()
        else:self.res[lid]=((operand-q)*(~mask)).half().float()
        hist=self.hist.setdefault(lid,dict(elements=0,bit_elements={}))
        hist['elements']+=B*H*N*N
        for bi in (4,6,8):hist['bit_elements'][str(bi)]=hist['bit_elements'].get(str(bi),0)+int((bits==bi).sum())*N
        out=base+q+correction
        return out,out

def main():
    torch.set_num_threads(4);torch.set_num_interop_threads(2);torch.manual_seed(42);torch.backends.cuda.matmul.allow_tf32=False
    res=dict(status='loading',scope='loaded_RWKV7_2.9B_40window_WikiText2_test_followup',not_full_benchmark=True,intervention='rank1_increment_vk_only; native S@ab term preserved',dtype='float32',gpu=torch.cuda.get_device_name(),torch=torch.__version__,started=time.time(),results={})
    save(res);model,tok=load_rwkv7('/REDACTED_PATH/rwkv7_2b9',dtype=torch.float32)
    print('model_loaded',flush=True)
    model.config.wkv_implementation='chunked'
    for m in model.modules():
        if hasattr(m,'config') and hasattr(m,'lora_gates'):m.config.wkv_implementation='chunked'
    raw=open('/REDACTED_PATH/wiki.test.tokens').read()
    cached=torch.load('/REDACTED_PATH/wiki.test.ids.pt')
    text=tok.decode(cached.tolist())
    assert raw.startswith(text), 'cached tokens do not reconstruct the source prefix'
    prefix=tok(raw[:1000],add_special_tokens=False)['input_ids']
    assert cached[:128].tolist()==prefix[:128], 'cached vocabulary/tokenizer mismatch'
    ids=cached[4096:]
    print('tokenized after reserved-pilot offset',len(ids),flush=True)
    res.update(parameters=sum(p.numel() for p in model.parameters()),tokenizer_vocab=tok.vocab_size,corpus_tokens=len(ids),data_sha256=hashlib.sha256(text.encode()).hexdigest(),shape=dict(layers=model.config.num_hidden_layers,heads=model.config.num_heads,head_dim=model.config.head_dim))
    identity=ids[:32][None].cuda()
    with torch.inference_mode():native=model(identity,use_cache=False).logits.float().cpu()
    ctrl=Ctrl();install(model,ctrl)
    with torch.inference_mode():patched=model(identity,use_cache=False).logits.float().cpu()
    err=(native-patched).abs();res['identity']=dict(max_abs_logits=float(err.max()),mean_abs_logits=float(err.mean()),argmax_agreement=float((native.argmax(-1)==patched.argmax(-1)).float().mean()),native_mode='original chunked registry',patched_mode='native recurrence, no quantization')
    if float(err.max())>1e-3:res['status']='identity_failed';save(res);return
    del native,patched;torch.cuda.empty_cache();res['status']='running';save(res)
    length=512;stride=256;nw=40
    assert len(ids)>=length+(nw-1)*stride
    xs=torch.stack([ids[i*stride:i*stride+length] for i in range(nw)]).cuda()
    targets=xs[:,1:];res['protocol']=dict(split='test',length=length,stride=stride,windows=nw,score='last 256 target positions/window; unique scoring positions; token offset 4096',scored_tokens=nw*stride,seed=42,calibration=None,input_sha256=hashlib.sha256(xs.cpu().numpy().tobytes()).hexdigest())
    specs=[('reference','none',8),('uniform8','uniform8',8),('uniform6','uniform6',6),('ema_masked_feedback_8_6','balanced',8),('no_energy_8_6','no_energy',8),('no_feedback_8_6','no_feedback',8),('no_routing_8_6','no_routing',8),('random_matched_histogram_8_6','random',8),('inverted_matched_histogram_8_6','inverted',8),('all_channel_pre_feedback_8_6','all_feedback',8)]
    for name,method,bits in specs:
        ctrl.method=method;ctrl.bits=bits;ctrl.reset();torch.cuda.synchronize();t0=time.perf_counter()
        all_scored=[];all_hist=[]
        for begin in range(0,nw,20):
            ctrl.batch_index=begin
            ctrl.reset()
            with torch.inference_mode():
                logits=model(xs[begin:begin+20],use_cache=False).logits[:,:-1].float()
                loss=F.cross_entropy(logits.reshape(-1,logits.size(-1)),targets[begin:begin+20].reshape(-1),reduction='none').reshape(min(20,nw-begin),length-1)
                all_scored.append(loss[:,-stride:].cpu());all_hist.append(ctrl.hist)
            del logits,loss
        scored=torch.cat(all_scored);means=scored.mean(1).tolist();total=float(scored.sum());count=scored.numel()
        torch.cuda.synchronize();seconds=time.perf_counter()-t0;mean=total/count
        row=dict(nll_sum=total,scored_tokens=count,mean_nll=mean,ppl=math.exp(mean) if mean<709 else None,window_mean_nll=means,elapsed_seconds=seconds,allocation_histograms=all_hist,decay_first_step=ctrl.decay,feedback=method,scope='patent-key-coordinate routing; gate-energy EMA .99; initial threshold .85/.95; high8 promoted8 base6; masked postquant feedback; FP16 residual; fake quant only')
        res['results'][name]=row
        with open(ROOT+'/fixedq_'+name+'_token_nll.json','w') as f:json.dump(scored.cpu().tolist(),f)
        save(res);print(name,json.dumps({k:row[k] for k in ['ppl','mean_nll','scored_tokens','elapsed_seconds']}),flush=True)
        del scored;torch.cuda.empty_cache()
    res['method_spec']=dict(matched_routing='random/inverted replay the temporal run per-sample/layer/step quotas and promotion schedule; actual histogram equality checked after execution',quantizer='fixed per-native-value-row absmax across keys, shared setting across all configurations; not a granularity sweep',decay_axis='native key coordinate, broadcast across value rows',threshold='prior EMA scalar per sample/layer; initial .85 balanced .95 aggressive; update .99 prior + .01 mean w',energy='L2 of w*(1-mask); prior EMA .99; promote if current >1.5 prior',bits='persistent8 transient6 promoted8',feedback='postquant correction w * previous transient residual * current persistent mask',residual='FP16 (u-Q(u)) on current transient coordinates',state='FP32 native S*w+S@ab preserved',control='native FP32');res['status']='completed';res['finished']=time.time();save(res)
if __name__=='__main__':
    try:main()
    except Exception:
        with open(ROOT+'/fixedq_error.txt','w') as f:f.write(traceback.format_exc())
        raise
