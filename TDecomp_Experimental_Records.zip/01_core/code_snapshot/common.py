"""Model loading, patching and sliding-window perplexity evaluation."""
import os
import sys
import types

import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

RWKV7_PATH = os.environ.get("RWKV7_PATH", "/REDACTED_PATH/rwkv7_2b9")
WIKI_TEST = os.environ.get(
    "WIKI_TEST", "/REDACTED_PATH/wiki.test.tokens")
RWKV7_PKG_DIR = os.environ.get("RWKV7_PKG_DIR", "/root")   # parent of rwkv7pkg

_REGISTERED = False


def register_rwkv7(pkg_parent=RWKV7_PKG_DIR):
    """Teach transformers about `model_type: rwkv7` using the repo's own code.

    transformers >= 5.x has no built-in RWKV-7, and several official RWKV-7
    checkpoints ship *weights only* (no modeling_*.py).  We import the modeling
    code from a standalone copy and register it with the Auto classes.
    """
    global _REGISTERED
    if _REGISTERED:
        return
    if pkg_parent not in sys.path:
        sys.path.insert(0, pkg_parent)
    from transformers import AutoConfig, AutoModelForCausalLM
    from rwkv7pkg.configuration_rwkv7 import Rwkv7Config
    from rwkv7pkg.modeling_rwkv7 import Rwkv7ForCausalLM
    try:
        AutoConfig.register("rwkv7", Rwkv7Config)
    except Exception:
        pass
    try:
        AutoModelForCausalLM.register(Rwkv7Config, Rwkv7ForCausalLM)
    except Exception:
        pass
    _REGISTERED = True


def load_tok(path):
    from transformers import AutoTokenizer
    try:
        return AutoTokenizer.from_pretrained(path)
    except Exception as e:  # unknown tokenizer class in transformers 5.x
        print(f"[tok] AutoTokenizer failed ({type(e).__name__}), "
              "falling back to tokenizers.Tokenizer")
        from tokenizers import Tokenizer
        from transformers import PreTrainedTokenizerFast
        tk = Tokenizer.from_file(os.path.join(path, "tokenizer.json"))
        return PreTrainedTokenizerFast(tokenizer_object=tk)


def load_rwkv7(path=RWKV7_PATH, dtype=torch.float16, device="cuda"):
    from transformers import AutoConfig, AutoModelForCausalLM
    register_rwkv7()
    cfg = AutoConfig.from_pretrained(path)
    model = AutoModelForCausalLM.from_pretrained(
        path, config=cfg, dtype=dtype, low_cpu_mem_usage=True)
    model = model.to(device).eval()
    tok = load_tok(path)
    return model, tok


def load_wiki(path=WIKI_TEST):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def build_windows(ids, seq_len=512, stride=256, n_windows=20):
    """Sliding windows; each window is scored from a FRESH recurrent state."""
    need = seq_len + (n_windows - 1) * stride + 1
    if ids.numel() < need:
        ids = torch.cat([ids, ids[: need - ids.numel() + 1]])
    xs, ys = [], []
    for i in range(n_windows):
        s = i * stride
        chunk = ids[s:s + seq_len + 1]
        if chunk.numel() < seq_len + 1:
            break
        xs.append(chunk[:-1])
        ys.append(chunk[1:])
    return torch.stack(xs), torch.stack(ys)


@torch.no_grad()
def eval_ppl(model, ids, seq_len=512, stride=256, n_windows=20, batch=20,
             device="cuda", logits_chunk=None):
    """Sliding-window perplexity under a fixed protocol.

    Windows are independent (fresh state each), so they are evaluated as a
    *batch*: the serial token loop then costs one pass instead of n_windows.
    Identical protocol for FP and every quantized run, so Delta-PPL is
    directly comparable.
    """
    import math
    model.eval()
    if logits_chunk is None:
        logits_chunk = batch
    xs, ys = build_windows(ids, seq_len, stride, n_windows)
    nll, cnt = 0.0, 0
    for s in range(0, xs.size(0), batch):
        x = xs[s:s + batch].to(device)
        y = ys[s:s + batch].to(device)
        logits = model(x, use_cache=False).logits
        ls = logits.float()
        nll += F.cross_entropy(ls.reshape(-1, ls.size(-1)), y.reshape(-1),
                               reduction="sum").item()
        cnt += y.numel()
    return float(math.exp(nll / cnt)), nll, cnt


def load_ids(path=None):
    path = path or os.environ.get(
        "IDS_PATH", "/REDACTED_PATH/wiki.test.ids.pt")
    return torch.load(path)
