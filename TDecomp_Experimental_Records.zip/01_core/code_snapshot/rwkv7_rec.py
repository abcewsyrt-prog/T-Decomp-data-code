"""Quantization hook for the *official* RWKV-7 HF modeling code.

The reference implementation (``rwkv7_recurrent``) is a pure-Python token loop

    S_t = S_{t-1} * diag(w_t)  +  S_{t-1} @ A_t  +  v_t k_t^T

with ``diag(w_t)`` multiplying on the RIGHT (key axis).  The official code
dispatches it through an open registry::

    RWKV7_WKV_FUNCTIONS = {"eager": ..., "chunked": ...}

so the whole recurrence can be replaced without forking ``modeling_rwkv7.py``.
We register a quantized drop-in under the key the config selects.

IMPORTANT (speed): ``Rwkv7Attention.forward`` computes
``tokenwise = config.wkv_implementation != "chunked"`` and, when True, runs
every projection as a Python loop over tokens -- ~200k kernel launches per
512-token window.  So we keep ``wkv_implementation = "chunked"`` (batched
projections) and override the ``"chunked"`` *registry entry* with our own
token-level quantized recurrence.  The flag only selects the linear path, so
this costs nothing in fidelity; and because FP and quantized runs share the
identical recurrence body, Delta-PPL is exactly apples-to-apples.
"""
import sys

import torch

from .rwkv7_hook import StateController  # noqa: F401  (re-exported)

__all__ = ["make_wkv_fn", "install", "set_layer_ids", "StateController"]


# --------------------------------------------------------------------------- #
#  Quantized recurrent kernel (drop-in for RWKV7_WKV_FUNCTIONS[...])           #
# --------------------------------------------------------------------------- #
def _rec(ctrl, r, w_log, k, v, kk, a, state, compute_dtype, cu_seq_lens):
    if cu_seq_lens is not None:
        bounds = cu_seq_lens.tolist()
        outs = []
        for s0, s1 in zip(bounds[:-1], bounds[1:]):
            if s1 <= s0:
                continue
            o, state = _rec(ctrl, r[:, s0:s1], w_log[:, s0:s1], k[:, s0:s1],
                            v[:, s0:s1], kk[:, s0:s1], a[:, s0:s1],
                            torch.zeros_like(state), compute_dtype, None)
            outs.append(o)
        return torch.cat(outs, dim=1), state

    B, T, H, N = r.shape
    lid = int(getattr(ctrl, "_lid", 0))
    act_dtype = r.dtype
    state_dtype = state.dtype

    S = state.to(compute_dtype)
    ctrl._ensure(ctrl.n_layer, B, H, N, act_dtype, r.device)
    out = torch.empty(B, T, H, N, device=r.device, dtype=compute_dtype)

    for t in range(T):
        decay = torch.exp(w_log[:, t])[:, :, None, :]              # [B,H,1,K]
        kk_t = kk[:, t]
        vk = v[:, t][..., None] @ k[:, t][:, :, None, :]           # v k^T
        ab = (-kk_t)[..., None] @ (kk_t * a[:, t])[:, :, None, :]  # -kk (kk a)^T
        S, S_read = ctrl.step(lid, S, decay, ab, vk, B, H, N, ctrl.n_layer,
                              v=v[:, t], k=k[:, t])
        out[:, t] = (S_read.to(act_dtype) @ r[:, t][..., None]).squeeze(-1).to(compute_dtype)

    return out.to(act_dtype), S.to(state_dtype)


def make_wkv_fn(ctrl):
    def wkv(r, w_log, k, v, kk, a, state, cu_seq_lens=None,
            compute_dtype=torch.float32, **kwargs):
        return _rec(ctrl, r, w_log, k, v, kk, a, state, compute_dtype, cu_seq_lens)
    return wkv


# --------------------------------------------------------------------------- #
#  Installation                                                                #
# --------------------------------------------------------------------------- #
def _module_of(obj):
    return sys.modules[obj.__module__]


def install(model, ctrl):
    """Route every layer's WKV through ``ctrl``.

    Returns (n_layers, n_heads, head_dim).
    """
    # Discover the attention modules structurally: any module carrying the
    # RWKV-7 low-rank gate block + a head_dim is a time-mixing layer.  This
    # survives `model.blocks` vs `model.layers` vs a wrapped/compiled model.
    atts = [m for m in model.modules()
            if hasattr(m, "lora_gates") and hasattr(m, "head_dim")]
    if not atts:
        raise RuntimeError("cannot locate RWKV-7 attention modules on "
                           f"{type(model).__name__}")
    atts.sort(key=lambda m: int(getattr(m, "layer_id", 0)))
    att0 = atts[0]
    mod = _module_of(att0)
    if not hasattr(mod, "RWKV7_WKV_FUNCTIONS"):
        raise RuntimeError(f"{mod.__name__} has no RWKV7_WKV_FUNCTIONS registry")

    n_layer = len(atts)
    H = int(getattr(att0, "num_heads"))
    N = int(getattr(att0, "head_dim"))
    ctrl.n_layer = n_layer
    ctrl.head_size = N
    ctrl._lid = 0

    # Batched projections + our token-loop recurrence (see module docstring).
    # `config` is shared by every layer, so setting it once is enough.
    try:
        model.config.wkv_implementation = "chunked"
    except Exception:
        pass
    for att in atts:
        if hasattr(att, "config"):
            try:
                att.config.wkv_implementation = "chunked"
            except Exception:
                pass

    fn = make_wkv_fn(ctrl)
    for key in list(mod.RWKV7_WKV_FUNCTIONS.keys()):
        mod.RWKV7_WKV_FUNCTIONS[key] = fn

    # per-layer id: wrap attn.forward so the kernel knows which layer it is in
    for att in atts:
        lid = int(getattr(att, "layer_id", 0))
        orig = att.forward

        def _mk(lid, orig):
            def fwd(*a, **kw):
                ctrl._lid = lid
                return orig(*a, **kw)
            return fwd

        att.forward = _mk(lid, orig)

    return n_layer, H, N
