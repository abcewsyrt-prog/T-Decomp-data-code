import os,sys,json,time,random,re,hashlib
from pathlib import Path
os.environ['HF_HUB_OFFLINE']='1';os.environ['TOKENIZERS_PARALLELISM']='false'
sys.path[:0]=['/REDACTED_ROOT','/REDACTED_PATH/tsq']
import torch
from tsq.common import load_rwkv7
from tsq.rwkv7_rec import install
from core_controller import Ctrl
ROOT=Path('/REDACTED_PATH/tdecomp_nc_20261028');OUT=ROOT/'full_retrieval.json'
FILLERS=['The atmospheric conditions remained calm throughout the afternoon. ','The library catalog contains records about local landscapes and ordinary plants. ','The river flows through the valley before reaching the open sea. ','A group of visitors examined the archive and then returned to the station. ','The report describes methods for recording changes in the natural environment. ']
LENGTHS=[1024,2048,4096,8192,16384];DEPTHS=[.1,.3,.5,.7,.9];N=100

def save(o):
 p=OUT.with_suffix('.tmp');p.write_text(json.dumps(o,indent=2,allow_nan=False));p.replace(OUT)
def main():
 torch.set_num_threads(4);torch.set_num_interop_threads(2);torch.manual_seed(42);torch.backends.cuda.matmul.allow_tf32=False
 model,tok=load_rwkv7('/REDACTED_PATH/rwkv7_2b9',dtype=torch.float32);c=Ctrl();install(model,c)
 header=tok('Read the following records.\n',add_special_tokens=False)['input_ids'];tail=tok('\nWhat is the special magic number for X? The special magic number for X is',add_special_tokens=False)['input_ids'];fill=[tok(x,add_special_tokens=False)['input_ids'] for x in FILLERS]
 # Check native recurrent-cache continuation, including masked EMA state.
 checks={};test=torch.tensor([header+fill[0]+fill[1]],device='cuda')
 for name,method in [('reference','none'),('masked','balanced')]:
  c.method=method;c.reset();c.schedules.clear()
  with torch.inference_mode():a=model(test,use_cache=False,logits_to_keep=1).logits
  c.reset();c.schedules.clear();mid=test.shape[1]//2
  with torch.inference_mode():first=model(test[:,:mid],use_cache=True,logits_to_keep=1);b=model(test[:,mid:],state=first.state,use_cache=True,logits_to_keep=1).logits
  diff=float((a-b).abs().max());checks[name]=diff
  if name=='reference':assert diff<1e-3,(name,diff)
  else:assert torch.isfinite(a).all() and torch.isfinite(b).all()
 result=json.loads(OUT.read_text()) if OUT.exists() else dict(status='running',protocol=dict(model='/REDACTED_PATH/rwkv7_2b9',dtype='FP32',quantizer='fixed native value-row absmax',lengths=LENGTHS,depths=DEPTHS,trials_per_cell=N,seed=73029,generation='greedy up to 16 tokens; stop at first period or newline after leading whitespace; EOS stops; exact comparison of entire answer before stop, no substring search or first-token proxy',state='monolithic prefill then native cached one-token decode; EMA and residual reset only per independent case; quantized chunk-partition diagnostic recorded separately',paired_cases=True),cache_checks=checks,results={})
 result['status']='running';save(result)
 for length in LENGTHS:
  for depth in DEPTHS:
   seed=73029+length+round(depth*1000);rng=random.Random(seed);cases=[]
   for i in range(N):
    key=str(rng.randint(10000,99999));needle=tok('The special magic number for X is '+key+'.\n',add_special_tokens=False)['input_ids'];budget=length-len(header)-len(tail)-len(needle);pool=[]
    while len(pool)<budget:pool+=rng.choice(fill)
    pool=pool[:budget];at=round(depth*budget);ids=header+pool[:at]+needle+pool[at:]+tail;assert len(ids)==length
    cases.append(dict(id=i,key=key,ids=ids,needle_index=len(header)+at))
   digest=hashlib.sha256(json.dumps(cases,separators=(',',':')).encode()).hexdigest()
   for config,method,bits in [('reference','none',8),('uniform8','uniform8',8),('uniform4','uniform4',4),('masked_ema_8_6','balanced',8)]:
    name=f'{length}/{depth:.1f}/{config}';records=result['results'].get(name,{}).get('records',[]);start=time.time()
    for begin in range(len(records),N,4):
     batch=cases[begin:begin+4];x=torch.tensor([z['ids'] for z in batch],device='cuda');c.method=method;c.bits=bits;c.reset();c.schedules.clear();state=None
     generated=[[] for z in batch];done=[False]*len(batch)
     with torch.inference_mode():
      out=model(x,state=None,use_cache=True,logits_to_keep=1);state=out.state
      for step in range(16):
       nxt=out.logits[:,-1].argmax(-1)
       for j in range(len(batch)):
        if not done[j]:
         z=int(nxt[j])
         if z==0:done[j]=True;continue
         generated[j].append(z);answer=tok.decode(generated[j]).lstrip();done[j]=bool(re.search(r'[.\n]',answer))
       if all(done):break
       nxt=torch.where(torch.tensor(done,device='cuda'),0,nxt)
       out=model(nxt[:,None],state=state,use_cache=True,logits_to_keep=1);state=out.state
     for j,z in enumerate(batch):
      raw=tok.decode(generated[j]);answer=re.split(r'[.\n]',raw.lstrip(),maxsplit=1)[0].strip();records.append(dict(id=z['id'],target=z['key'],answer=answer,raw_generated=raw,exact_match=answer==z['key'],needle_index=z['needle_index']))
     row=dict(n=len(records),successes=sum(int(z['exact_match']) for z in records),records=records,input_sha256=digest,complete=len(records)==N);row['exact_match_rate']=row['successes']/row['n'];result['results'][name]=row;save(result);print(name,row['n'],row['successes'],flush=True)
     del x,out,state;torch.cuda.empty_cache()
 result['status']='completed';save(result)
if __name__=='__main__':main()
