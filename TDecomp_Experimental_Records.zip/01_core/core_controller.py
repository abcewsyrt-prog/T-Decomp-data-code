import torch
class Ctrl:
    def __init__(self):self.method='none';self.bits=8;self.n_layer=1;self._lid=0;self.schedules={};self.batch_index=0;self.reset()
    def reset(self):self.res={};self.steps={};self.hist={};self.decay={};self.threshold={};self.energy={}
    def _ensure(self,*a):pass
    def step(self,lid,S,w,ab,vk,B,H,N,L,v=None,k=None):
        w=w.float();ab=ab.float();vk=vk.float();base=S.float()*w+S.float()@ab
        if self.method=='none':return base+vk,base+vk
        if self.method.startswith('uniform'):
            bits=torch.full_like(w,int(self.bits),dtype=torch.int64);mask=torch.zeros_like(w,dtype=torch.bool)
        else:
            initial=.95 if self.method=='aggressive' else .85
            threshold=self.threshold.get(lid,torch.full((B,1,1,1),initial,device=w.device))
            # Native w is [B,H,1,N]: route key coordinates, broadcast over value rows.
            mask=w>=threshold
            if self.method=='no_routing':mask=torch.zeros_like(mask)
            gate=w*(~mask)
            energy=gate.square().sum((1,2,3),keepdim=True).sqrt()
            prior=self.energy.get(lid,energy)
            promote=energy>1.5*prior
            if self.method=='no_energy':promote=torch.zeros_like(promote)
            # Balanced historical format family: INT8 high/promoted, INT6 base.
            bits=torch.where(mask,8,torch.where(promote,8,6))
            step=self.steps.get(lid,0)
            if self.method=='balanced':self.schedules[(self.batch_index,lid,step)]=(mask.reshape(B,-1).sum(-1,keepdim=True).clone(),promote.clone())
            if self.method in ('random','inverted'):
                flat=mask.reshape(B,-1)
                count,promote=self.schedules[(self.batch_index,lid,step)]
                if self.method=='random':
                    g=torch.Generator(device=w.device);g.manual_seed(42+lid*100000+self.steps.get(lid,0))
                    score=torch.rand(flat.shape,device=w.device,generator=g)
                else:score=-w.reshape(B,-1)
                order=score.argsort(dim=-1,descending=True,stable=True)
                rank=torch.empty_like(order);rank.scatter_(1,order,torch.arange(order.shape[1],device=w.device).expand_as(order))
                mask=(rank<count).reshape_as(mask)
                bits=torch.where(mask,8,torch.where(promote,8,6))
            self.steps[lid]=self.steps.get(lid,0)+1
            self.threshold[lid]=.99*threshold+.01*w.mean((1,2,3),keepdim=True)
            self.energy[lid]=.99*prior+.01*energy
        r=self.res.get(lid,torch.zeros_like(vk))
        if self.method=='all_feedback':operand=vk+w*r;correction=0
        else:operand=vk;correction=w*r*mask if self.method not in ('no_feedback','none') and not self.method.startswith('uniform') else 0
        qm=2.**(bits.float()-1)-1
        scale=operand.abs().amax(-1,keepdim=True).clamp_min(1e-12)/qm
        q=torch.round(operand/scale).clamp(-qm,qm)*scale
        if self.method=='all_feedback':self.res[lid]=(operand-q).half().float()
        else:self.res[lid]=((operand-q)*(~mask)).half().float()
        hist=self.hist.setdefault(lid,dict(elements=0,bit_elements={}))
        hist['elements']+=B*H*N*N
        for bi in (4,6,8):hist['bit_elements'][str(bi)]=hist['bit_elements'].get(str(bi),0)+int((bits==bi).sum())*N
        out=base+q+correction
        return out,out
